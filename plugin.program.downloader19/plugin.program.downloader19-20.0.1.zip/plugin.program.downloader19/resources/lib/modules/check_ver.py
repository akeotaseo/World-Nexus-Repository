
import xbmc
from updatervar import *
from resources.lib.GUIcontrol import notify
from resources.lib.GUIcontrol.notify import get_notifyversion
from resources.lib.GUIcontrol.txt_updater import get_updaterversion, get_xmlskin, get_players

updater_version = get_updaterversion()
notify_version = get_notifyversion()
xmlskin_version = get_xmlskin()
players_version = get_players()


def updater():
	if not setting('updaterversion') == 'false':
		if updater_version > int(setting('updaterversion')):
			xbmc.executebuiltin(Updater_startup)
			xbmc.sleep(25000)
			xbmc.executebuiltin(downloader_startup)
			setting_set('updaterversion', str(updater_version))
		else:
			if os.path.exists (downloader_startup_tk):
				xbmc.sleep(15000)
				xbmc.executebuiltin(downloader_startup)


def notifyT():
	if not setting('firstrunNotify')=='false':
		if notify_version > int(setting('notifyversion')):
			setting_set('notifyversion', str(notify_version))
			d=notify.notify()
			d.doModal()
			del d


def xmlskin():
	if not setting('xmlskinversion') == 'false':
		if xmlskin_version > int(setting('xmlskinversion')):
			BG.create(Dialog_U8, Dialog_Xml_Skin)
			BG.update(5, Dialog_U8, Dialog_Xml_Skin)
			xbmc.sleep(200)
			BG.update(15, Dialog_U8, Dialog_Xml_Skin)
			xbmc.sleep(200)
			xbmc.executebuiltin(XmlSkin_startup)
			xbmc.sleep(1000)
			BG.update(25, Dialog_U8, Dialog_Xml_Skin)
			xbmc.sleep(500)
			setting_set('xmlskinversion', str(xmlskin_version))
			BG.update(55, Dialog_U8, Dialog_Xml_Skin)
			xbmc.sleep(200)
			BG.update(75, Dialog_U8, Dialog_Xml_Skin)
			xbmc.sleep(200)
			BG.update(80, Dialog_U8, Dialog_U9)
			xbmc.sleep(1000)
			BG.update(90, Dialog_U1, '[B]Ενημέρωση μενού skin[/B]')
			xbmc.sleep(3000)
			BG.update(95, Dialog_U4, 'Θα ακολουθήσει... επαναφόρτωση του προφίλ')
			xbmc.sleep(3000)
			xbmcgui.Dialog().notification("[B][COLOR orange]Reload Profile[/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/reloadprofile.png')
			xbmc.sleep(500)
			BG.update(100, Dialog_U4, 'Θα ακολουθήσει... και πάγωμα της εικόνας')
			xbmc.sleep(2000)
			xbmc.executebuiltin("LoadProfile(Master user)")
			BG.close()

def players():
	if not setting('playersversion') == 'false':
		if players_version > int(setting('playersversion')):
			BG.create(Dialog_U8, Dialog_Players)
			xbmc.sleep(200)
			BG.update(5, Dialog_U8, Dialog_Players)
			xbmc.sleep(200)
			BG.update(15, Dialog_U8, Dialog_Players)
			xbmc.executebuiltin(Players_startup)
			xbmc.sleep(1500)
			BG.update(25, Dialog_U8, Dialog_Players)
			xbmc.sleep(500)
			setting_set('playersversion', str(players_version))
			BG.update(55, Dialog_U8, Dialog_Players)
			xbmc.sleep(200)
			BG.update(75, Dialog_U8, Dialog_Players)
			xbmc.sleep(200)
			BG.update(100, Dialog_U8, Dialog_U9)
			xbmc.sleep(1000)
			BG.close()
