﻿# -*- coding: utf-8 -*-
import os, xbmc
from updatervar import *
from resources.lib.modules import addonsEnable, check_ver


if __name__ == '__main__':
	if not setting('updaterversion') == 'false':
		dialog.notification(Dialog_welcome, Dialog_Update, icon_Build, sound=False)
	else:
		dialog.notification(Dialog_welcome, Dialog_not_Updater, icon_Build, sound=False)
	check_ver.xmlskin()
	check_ver.players()
	check_ver.updater()
	check_ver.notifyT()

	if not xbmc.getCondVisibility('UpdateAddonRepos'):
		addonsEnable.enable_addons()
		dialog.notification('Check Updates', 'Ελεγχος για ενημερώσεις προσθέτων', icon_auto2, sound=False)

	monitor = xbmc.Monitor()

	while not monitor.abortRequested():
		if monitor.waitForAbort(2*60*60):#διάστημα 2ωρών μεταξύ των ενημερώσεων
			break
		xbmc.executebuiltin('UpdateAddonRepos()')
		dialog.notification('Υπηρεσία ενημέρωσης', 'Εκκίνηση ενημερώσεων προσθέτων', icon_auto, sound=False)
