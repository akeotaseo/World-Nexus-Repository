
import xbmc
from updatervar import *
from resources.lib.GUIcontrol import notify
from resources.lib.GUIcontrol.notify import get_notifyversion
from resources.lib.GUIcontrol.txt_updater import get_addonsrepos, get_updaterversion, get_xmlskin, get_players, get_set_setting, get_var
from resources.lib.GUIcontrol.txt_updater import get_addons_list_installation, get_delete_files, get_zip1, get_zip2, get_zip3, get_zip4, get_zip5
from resources.lib.modules import addonsEnable

addons_list_installation_version = get_addons_list_installation()
notify_version       = get_notifyversion()
addons_repos_version = get_addonsrepos()
updater_version      = get_updaterversion()
xmlskin_version      = get_xmlskin()
players_version      = get_players()
set_setting_version  = get_set_setting()
delete_files_version = get_delete_files()
var_version          = get_var()
zip1_version         = get_zip1()
zip2_version         = get_zip2()
zip3_version         = get_zip3()
zip4_version         = get_zip4()
zip5_version         = get_zip5()



def autoenable():
    if setting('autoenable') == 'true':
        addonsEnable.enable_addons()
        setting_set('autoenable','false')
        dialog.notification(Dialog_enable_on, Dialog_enable, icon_Build, sound=False)


def var():
    BG.create(Dialog_U8, 'Ενημέρωση σε εξέλιξη...')
    if var_version > int(setting('varversion')):
        BG.update(5, Dialog_U8, Dialog_U2)
        xbmc.executebuiltin(Var_startup)
        xbmc.sleep(1000)
        setting_set('varversion', str(var_version))


def players():
    if players_version > int(setting('playersversion')):
        BG.update(15, Dialog_U8, Dialog_Players)
        xbmc.executebuiltin(Players_startup)
        xbmc.sleep(2000)
        setting_set('playersversion', str(players_version))


def delete():
    if delete_files_version > int(setting('deleteversion')):
        xbmc.executebuiltin(Delete_startup)
        BG.update(25, Dialog_U1, Dialog_U11)
        xbmc.sleep(16000)
        xbmc.executebuiltin(del_startup)
    #    BG.update(26, Dialog_U1, 'Καταχώριση έκδοσης στις ρυθμίσεις...')
        xbmc.sleep(1000)
        setting_set('deleteversion', str(delete_files_version))
        BG.update(28, Dialog_U1, Dialog_U10)
        xbmc.sleep(5000)


def zip1():
    if zip1_version > int(setting('zip1version')):
        BG.update(30, Dialog_U3, Dialog_U2)
        xbmc.executebuiltin(Zip1_startup)
        xbmc.sleep(1000)
        setting_set('zip1version', str(zip1_version))


def zip2():
    if zip2_version > int(setting('zip2version')):
        BG.update(35, Dialog_U3, Dialog_U2)
        xbmc.executebuiltin(Zip2_startup)
        xbmc.sleep(1000)
        setting_set('zip2version', str(zip2_version))


def zip3():
    if zip3_version > int(setting('zip3version')):
        BG.update(40, Dialog_U3, Dialog_U2)
        xbmc.executebuiltin(Zip3_startup)
        xbmc.sleep(1000)
        setting_set('zip3version', str(zip3_version))


def zip4():
    if zip4_version > int(setting('zip4version')):
        BG.update(45, Dialog_U3, Dialog_U2)
        xbmc.executebuiltin(Zip4_startup)
        xbmc.sleep(1000)
        setting_set('zip4version', str(zip4_version))


def zip5():
    if zip5_version > int(setting('zip5version')):
        BG.update(50, Dialog_U3, Dialog_U2)
        xbmc.executebuiltin(Zip5_startup)
        xbmc.sleep(1000)
        setting_set('zip5version', str(zip5_version))


def installation():
    if addons_list_installation_version > int(setting('installationversion')):
        BG.update(55, Dialog_U1, 'Έλεγχος εγκατάστασης νέων πρόσθετων...')
        xbmc.executebuiltin(Installation_startup)
        xbmc.sleep(16000)
        xbmc.executebuiltin(install_startup)
    #    BG.update(56, Dialog_U1, 'Καταχώριση έκδοσης στις ρυθμίσεις...')
        xbmc.sleep(1000)
        setting_set('installationversion', str(addons_list_installation_version))
        BG.update(57, Dialog_U1, 'Προσθήκη νέων πρόσθετων...')
        xbmc.sleep(12000)

def updater():
    if updater_version > int(setting('updaterversion')):
        BG.update(60, Dialog_U1, Dialog_U2)
        xbmc.executebuiltin(Updater_startup)
        xbmc.sleep(25000)
        xbmc.executebuiltin(downloader_startup)
        setting_set('updaterversion', str(updater_version))
    else:
        if os.path.exists (downloader_startup_tk):
            xbmc.sleep(15000)
            xbmc.executebuiltin(downloader_startup)
            setting_set('updaterversion', str(updater_version))
#        xbmc.sleep(10000)


def setsetting():
    if set_setting_version > int(setting('setsettingversion')):
        BG.update(65, Dialog_U1, Dialog_U2)
        xbmc.executebuiltin(SetSetting_startup)
        xbmc.sleep(16000)
        xbmc.executebuiltin(set_setting_startup)
        BG.update(68, Dialog_U1, 'Καταχώριση έκδοσης στις ρυθμίσεις...')
        xbmc.sleep(1000)
        setting_set('setsettingversion', str(set_setting_version))


def database():
    if addons_repos_version > int(setting('addonsreposversion')):
        BG.update(70, Dialog_U1, Dialog_Database)
        xbmc.executebuiltin(AddonsRepos_startup)
        xbmc.sleep(16000)
        xbmc.executebuiltin(database_startup)
        BG.update(78, Dialog_U1, 'Καταχώριση έκδοσης στις ρυθμίσεις...')
        xbmc.sleep(1000)
        setting_set('addonsreposversion', str(addons_repos_version))
        addonsEnable.enable_addons()
        BG.update(79, Dialog_U1, '[COLOR lime]Ενεργοποίηση πρόσθετων...[/COLOR]')
        xbmc.sleep(5000)

def xmlskin():
    if xmlskin_version > int(setting('xmlskinversion')):
        BG.update(85, Dialog_U1, Dialog_Xml_Skin)
        xbmc.executebuiltin(XmlSkin_startup)
        xbmc.sleep(5000)
        setting_set('xmlskinversion', str(xmlskin_version))
        BG.update(100, Dialog_U1, Dialog_ReloadSkin)
        xbmc.sleep(5000)
        xbmc.executebuiltin("ReloadSkin()")


def UpdateAddonRepos():
        xbmc.executebuiltin('UpdateLocalAddons')
        xbmc.executebuiltin('UpdateAddonRepos')
        BG.update(100, Dialog_U1, Dialog_U6)
        xbmc.sleep(5000)
        BG.close()

def notifyT():
    if not setting('firstrunNotify')=='false':
        if notify_version > int(setting('notifyversion')):
            xbmc.sleep(12000)
            setting_set('notifyversion', str(notify_version))
            d=notify.notify()
            d.doModal()
            del d

