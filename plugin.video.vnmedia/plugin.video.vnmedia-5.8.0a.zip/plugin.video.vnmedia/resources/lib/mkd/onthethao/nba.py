from codequick import Route, Listitem, Resolver
from resources.lib.kedon import getlink, quangcao
from bs4 import BeautifulSoup
@Route.register
def index_nba(plugin):
	yield []
	try:
		url = 'https://stream.tructiepnba.com/'
		resp = getlink(url, url, 400)
		if (resp is not None):
			soup = BeautifulSoup(resp.content, 'html.parser')
			soups = soup.select('div.wp-block-group__inner-container')
			for block in soups:
				try:
					title = block.h2.get_text(strip=True)
					time = block.p.get_text(strip=True)
					buttons = block.select('a.wp-block-button__link')
					for button in buttons:
						item = Listitem()
						tenm = f'{button.text.strip()} - {time}: {title}'
						item.label = tenm
						item.info['mediatype'] = 'tvshow'
						item.art['thumb'] = item.art['poster'] = 'https://mi3s.top/thumb/thethao/nba.png'
						item.set_callback(list_nba, button['href'], tenm)
						yield item
				except:
					pass
		else:
			yield quangcao()
	except:
		yield quangcao()
@Route.register
def list_nba(plugin, url=None, title=None):
	yield []
	if any((url is None,title is None)):
		pass
	else:
		try:
			resp = getlink(url, url, 400)
			if (resp is not None):
				item1 = Listitem()
				tenm = f'SV1 - {title}'
				item1.label = tenm
				item1.info['mediatype'] = 'episode'
				item1.art['thumb'] = item1.art['poster'] = 'https://mi3s.top/thumb/thethao/nba.png'
				item1.set_callback(Resolver.ref('/resources/lib/kedon:ifr_khomuc'), url, tenm)
				yield item1
				soup = BeautifulSoup(resp.content, 'html.parser')
				soups = soup.select('pagelinkselement#post-pagination a')
				for episode in soups:
					item = Listitem()
					tenk = f'{episode.get_text(strip=True)} - {title}'
					item.label = tenk
					item.info['mediatype'] = 'episode'
					item.art['thumb'] = item.art['poster'] = 'https://mi3s.top/thumb/thethao/nba.png'
					item.set_callback(Resolver.ref('/resources/lib/kedon:ifr_khomuc'), episode['href'], tenk)
					yield item
			else:
				yield quangcao()
		except:
			yield quangcao()