from codequick import Route, Listitem, run
@Route.register
def root(plugin, content_type='video'):
    # yield Listitem.search(Route.ref('/resources/lib/mkd/onfshare/timfshare:searchvnm'))
    streams = [
        # ('Free Film', 'https://raw.githubusercontent.com/kenvnm/kvn/main/phimmienphi.png', '/resources/lib/mkd/phim:index_phim'),
        # ('Fshare', 'https://raw.githubusercontent.com/kenvnm/kvn/main/fshare.png', '/resources/lib/mkd/fshare:index_fshare'),
        # ('Youtube', 'https://raw.githubusercontent.com/kenvnm/kvn/main/youtube.png', '/resources/lib/mkd/ytube:index_youtube'),
        # ('Truyền hình', 'https://raw.githubusercontent.com/kenvnm/kvn/main/truyenhinh.png', '/resources/lib/mkd/truyenhinh:listiptv_root'),
        # ('Thể thao', 'https://raw.githubusercontent.com/kenvnm/kvn/main/thethao.png', '/resources/lib/mkd/thethao:index_thethao'),
        ('Sports Sites', 'https://raw.githubusercontent.com/kenvnm/kvn/main/thethao.png', '/resources/lib/mkd/thethao:index_thethao'),
        # ('Tin tức', 'https://raw.githubusercontent.com/kenvnm/kvn/main/tintuc.png', '/resources/lib/mkd/tintuc:index_tintuc'),
        # ('Âm nhạc', 'https://raw.githubusercontent.com/kenvnm/kvn/main/amnhac.png', '/resources/lib/mkd/nhac:index_amnhac'),
        # ('Thiếu nhi', 'https://raw.githubusercontent.com/kenvnm/kvn/main/thieunhi.png', '/resources/lib/mkd/thieunhi:index_thieunhi'),
        # ('Giải trí', 'https://raw.githubusercontent.com/kenvnm/kvn/main/giaitri.png', '/resources/lib/mkd/giaitri:index_giaitri'),
        # ('Góc chia sẻ', 'https://raw.githubusercontent.com/kenvnm/kvn/main/gocchiase.png', '/resources/lib/mkd/onfshare/gcs:index_gcs'),
        # ('Tiện ích', 'https://raw.githubusercontent.com/kenvnm/kvn/main/tienich.png', '/resources/lib/mkd/tienich:index_tienich')
    ]
    for name_key, banner_key, url_key in streams:
        item = Listitem()
        item.label = name_key
        item.info['mediatype'] = 'tvshow'
        item.art['thumb'] = item.art['poster'] = banner_key
        item.set_callback(Route.ref(url_key))
        yield item
if __name__ == '__main__':
    run()