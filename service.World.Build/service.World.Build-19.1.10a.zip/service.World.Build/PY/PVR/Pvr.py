import xbmc, xbmcgui


def pvr():
    funcs = (click_1, click_2)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ PVR~[/COLOR][/B]', 
['[COLOR=white][COLOR green]Ιστότοποι[/COLOR][/COLOR]',

 '[COLOR=white][COLOR blue]Προσθήκη/Αλλαγή πύλης[/COLOR] [/COLOR]'],)


    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


def click_1():
    xbmc.executebuiltin('RunScript("special://home/addons/service.World.Build/PY/PVR/Browser_Portal_Stalker.py")')

def click_2():
    xbmc.executebuiltin('Addon.Opensettings(pvr.stalker)')





pvr()
