"""
This module exists only to simplify retrieving the version number of chardet
from within setup.py and from chardet subpackages.

:author: Dan Blanchard (dan.blanchard@gmail.com)
"""

__version__ = "5.0.0dev0"
VERSION = __version__.split(".")
