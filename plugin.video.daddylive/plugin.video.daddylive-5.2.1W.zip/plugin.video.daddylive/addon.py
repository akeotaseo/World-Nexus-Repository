# -*- coding: utf-8 -*-
'''
***********************************************************
*
* @file addon.py
* @package plugin.video.daddylive
*
* Created on 2024-03-08.
* Copyright 2024 by The Crew. All rights reserved.
*
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*
'''

import re
import os
import sys
import json
import html
import math
import time
import base64

from urllib.parse import urlencode, unquote, parse_qsl, quote_plus, urlparse, urljoin
from datetime import datetime, timezone

import requests
import xbmc
import xbmcvfs
import xbmcgui
import xbmcplugin
import xbmcaddon


addon_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.daddylive')

UA = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36'
FANART = addon.getAddonInfo('fanart')
ICON = addon.getAddonInfo('icon')

SEED_BASEURL = 'https://dlive.sx/'
WINDOW = xbmcgui.Window(10000)
BASE_PROP = 'daddylive.active_baseurl'
PROXY_PORT_PROP = 'daddylive.segmentproxy.port'
PROXY_DIR_PROP = 'daddylive.segmentproxy.manifestdir'
LOG_MAX_BYTES = 2 * 1024 * 1024

def log(msg):
    if addon.getSetting('debug_log') != 'true':
        return
    logpath = xbmcvfs.translatePath('special://logpath/')
    filename = 'daddylive.log'
    log_file = os.path.join(logpath, filename)
    try:
        if isinstance(msg, str):
            _msg = f'\n    {msg}'
        else:
            _msg = f'\n    {repr(msg)}'
        if not os.path.exists(log_file):
            with open(log_file, 'w', encoding='utf-8'):
                pass
        elif os.path.getsize(log_file) > LOG_MAX_BYTES:
            os.replace(log_file, log_file + '.1')
        with open(log_file, 'a', encoding='utf-8') as f:
            line = ('[{} {}]: {}').format(datetime.now().date(), str(datetime.now().time())[:8], _msg)
            f.write(line.rstrip('\r\n') + '\n')
    except (TypeError, Exception) as e:
        try:
            xbmc.log(f'[ Daddylive ] Logging Failure: {e}', 2)
        except:
            pass

def normalize_origin(url):
    try:
        u = urlparse(url)
        return f'{u.scheme}://{u.netloc}/'
    except:
        return SEED_BASEURL

def resolve_active_baseurl(seed):
    try:
        s = requests.Session()
        headers = {'User-Agent': UA}
        resp = s.get(seed, headers=headers, timeout=10, allow_redirects=True)
        final = normalize_origin(resp.url if resp.url else seed)
        return final
    except Exception as e:
        log(f'Active base resolve failed, using seed. Error: {e}')
        return normalize_origin(seed)

def get_active_base():
    base = WINDOW.getProperty(BASE_PROP)
    if not base:
        base = resolve_active_baseurl(SEED_BASEURL)
        WINDOW.setProperty(BASE_PROP, base)
    if not base.endswith('/'):
        base += '/'
    return base

def set_active_base(new_base: str):
    if not new_base.endswith('/'):
        new_base += '/'
    WINDOW.setProperty(BASE_PROP, new_base)

def abs_url(path: str) -> str:
    return urljoin(get_active_base(), path.lstrip('/'))

def get_local_time(utc_time_str):
    try:
        utc_now = datetime.utcnow()
        event_time_utc = datetime.strptime(utc_time_str, '%H:%M')
        event_time_utc = event_time_utc.replace(year=utc_now.year, month=utc_now.month, day=utc_now.day)
        event_time_utc = event_time_utc.replace(tzinfo=timezone.utc)
        local_time = event_time_utc.astimezone()
        time_format_pref = addon.getSetting('time_format')
        if time_format_pref == '1':
            local_time_str = local_time.strftime('%H:%M')
        else:
            local_time_str = local_time.strftime('%I:%M %p').lstrip('0')
        return local_time_str
    except Exception as e:
        log(f"Failed to convert time: {e}")
        return utc_time_str

def build_url(query):
    return addon_url + '?' + urlencode(query)

def clean_text(text):
    return re.sub(r'\s+', ' ', text.encode('ascii', 'ignore').decode('ascii')).strip() or text

def addDir(title, dir_url, is_folder=True):
    title = clean_text(title)
    li = xbmcgui.ListItem(title)
    clean_plot = re.sub(r'<[^>]+>', '', title)
    labels = {'title': title, 'plot': clean_plot, 'mediatype': 'video'}
    kodiversion = getKodiversion()
    if kodiversion < 20:
        li.setInfo("video", labels)
    else:
        infotag = li.getVideoInfoTag()
        infotag.setMediaType(labels.get("mediatype", "video"))
        infotag.setTitle(labels.get("title", "Daddylive"))
        infotag.setPlot(labels.get("plot", labels.get("title", "Daddylive")))
    li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': ICON, 'fanart': FANART})
    li.setProperty("IsPlayable", 'false' if is_folder else 'true')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=dir_url, listitem=li, isFolder=is_folder)

def closeDir():
    xbmcplugin.endOfDirectory(addon_handle)

def getKodiversion():
    try:
        return int(xbmc.getInfoLabel("System.BuildVersion")[:2])
    except:
        return 18

def Main_Menu():
    # Color rank: gold = watch, lightblue = find, lightgreen = tools.
    # Title case (White OK)  -  quieter than ALL CAPS shout.
    menu = [
        ['[COLOR gold]Live Sports Schedule[/COLOR]', 'sched'],
        ['[COLOR gold]Live TV Channels[/COLOR]', 'live_tv'],
        ['[COLOR lightblue]Search Events Schedule[/COLOR]', 'search'],
        ['[COLOR lightblue]Search Live TV Channels[/COLOR]', 'search_channels'],
        ['[COLOR lightgreen]Refresh Categories[/COLOR]', 'refresh_sched'],
        ['[COLOR lightgreen]Set Active Domain (Auto)[/COLOR]', 'resolve_base_now'],
    ]
    for m in menu:
        addDir(m[0], build_url({'mode': 'menu', 'serv_type': m[1]}))
    closeDir()


def getCategTrans():
    schedule_url = abs_url('index.php')
    try:
        headers = {'User-Agent': UA, 'Referer': get_active_base()}
        html_text = requests.get(schedule_url, headers=headers, timeout=10).text

        m = re.search(r'<div[^>]+class="filters"[^>]*>(.*?)</div>', html_text, re.IGNORECASE | re.DOTALL)
        if not m:
            log("getCategTrans(): filters block not found")
            return []

        block = m.group(1)
        anchors = re.findall(r'<a[^>]+href="([^"]+)"[^>]*>(.*?)</a>', block, re.IGNORECASE | re.DOTALL)
        if not anchors:
            log("getCategTrans(): no <a> items in filters block")
            return []

        categs = []
        seen = set()

        for href, text_content in anchors:
            name = html.unescape(re.sub(r'\s+', ' ', text_content)).strip()
            if not name or name.lower() == 'all':
                continue
            if name in seen:
                continue
            seen.add(name)
            categs.append((name, '[]'))

        return categs

    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"Error fetching category data: {e}")
        log(f'index parse fail: url={schedule_url} err={e}')
        return []

def Menu_Trans():
    categs = getCategTrans()
    if not categs:
        closeDir()
        return
    for categ_name, _events_list in categs:
        addDir(categ_name, build_url({'mode': 'showChannels', 'trType': categ_name}))
    closeDir()

def ShowChannels(categ, channels_list):
    for item in channels_list:
        title = item.get('title')
        addDir(title, build_url({'mode': 'trList', 'trType': categ, 'channels': json.dumps(item.get('channels'))}), True)
    closeDir()

def getTransData(categ):
    try:
        url = abs_url('index.php?cat=' + quote_plus(categ))
        headers = {'User-Agent': UA, 'Referer': get_active_base()}
        html_text = requests.get(url, headers=headers, timeout=10).text

        cut = re.search(r'<h2\s+class="collapsible-header\b', html_text, re.IGNORECASE)
        if cut:
            html_text = html_text[:cut.start()]

        events = re.findall(
            r'<div\s+class="schedule__event">.*?'
            r'<div\s+class="schedule__eventHeader"[^>]*?>\s*'
            r'(?:<[^>]+>)*?'
            r'<span\s+class="schedule__time"[^>]*data-time="([^"]+)"[^>]*>.*?</span>\s*'
            r'<span\s+class="schedule__eventTitle">\s*([^<]+)\s*</span>.*?'
            r'</div>\s*'
            r'<div\s+class="schedule__channels">(.*?)</div>',
            html_text, re.IGNORECASE | re.DOTALL
        )

        trns = []
        for time_str, event_title, channels_block in events:
            e = ''
            event_time_local = get_local_time(time_str.strip())
            # event_title = '| [B][COLOR white]%s[/COLOR][/B]' % event_title
            event_title = '| [B][COLOR white]%s[/COLOR][/B]' % event_title
            # e = '[COLOR orange][CR]'+'[COLOR white]%s[/COLOR]' % e
            e = '[COLOR chocolate]/ [/COLOR][COLOR slver]'+'[COLOR slver]%s[/COLOR]' % e
            event_title = event_title.replace(': ', e)

            event_title = event_title.replace('Greece', '[COLOR blue]Greece[/COLOR]').replace('Greek', '[COLOR blue]Greek[/COLOR]').replace('GREEK', '[COLOR blue]GREEK[/COLOR]').replace('GRE', '[COLOR blue]GRE[/COLOR]')
            event_title = event_title.replace('''Women's''', '''[COLOR deeppink]Women's[/COLOR]''').replace('Womens', '[COLOR deeppink]Womens[/COLOR]').replace('Women', '[COLOR deeppink]Women[/COLOR]').replace('Feminino', '([COLOR deeppink]Feminino[/COLOR])')
            event_title = event_title.replace('(W)', '([COLOR deeppink]W[/COLOR])').replace('(F)', '([COLOR deeppink]F[/COLOR])')
            event_title = event_title.replace('(M)', '([COLOR deepskyblue]M[/COLOR])')
            event_title = event_title.replace('Panathinaicos', '[COLOR springgreen]Panathinaikos[/COLOR]')
            event_title = event_title.replace('Panathinaikos', '[COLOR springgreen]Panathinaikos[/COLOR]')
            event_title = event_title.replace('Olympiacos', '[COLOR red]Olympiacos[/COLOR]')
            event_title = event_title.replace('Olympiakos', '[COLOR red]Olympiakos[/COLOR]')
            event_title = event_title.replace('Friendly', '[COLOR teal]Friendly[/COLOR]')
            event_title = event_title.replace('Simulcast', '[COLOR olive]Simulcast[/COLOR]')

            event_title = event_title.replace('Aris', '[COLOR yellow]Aris[/COLOR]').replace('ARIS', '[COLOR yellow]ARIS[/COLOR]')
            event_title = event_title.replace('Aek', '[COLOR yellow]Aek[/COLOR]').replace('AEK', '[COLOR yellow]AEK[/COLOR]')
            event_title = event_title.replace('Paok', '[COLOR white]Paok[/COLOR]').replace('PAOK', '[COLOR white]PAOK[/COLOR]')
            event_title = event_title.replace('Panionios', '[COLOR deepskyblue]Pan[COLOR red]ionios[/COLOR]')
            event_title = event_title.replace('WNBA', '[COLOR mediumpurple]WNBA[/COLOR]')
            event_title = event_title.replace('NBA ', '[COLOR cornflowerblue]NBA [/COLOR]')
            # event_title = event_title.replace('Basket League ', '[COLOR blue]Basket League [/COLOR]')
            event_title = event_title.replace('Euroleague', '[COLOR orange]Euroleague[/COLOR]')
            # event_title = event_title.replace('UEFA', '[COLOR crimson]UEFA[/COLOR]')
            event_title = event_title.replace('UEFA Champions League', '[COLOR blue]UEFA Champions League[/COLOR]')
            event_title = event_title.replace('UEFA Europa League', '[COLOR orangered]UEFA Europa League[/COLOR]')
            event_title = event_title.replace('UEFA Conference League', '[COLOR limegreen]UEFA Conference League[/COLOR]')
            title = f'[COLOR gold]{event_time_local}[/COLOR] {html.unescape(event_title.strip())}'


            chans = []
            for href, title_attr, link_text in re.findall(
                r'<a[^>]+href="([^"]+)"[^>]*title="([^"]*)"[^>]*>(.*?)</a>',
                channels_block, re.IGNORECASE | re.DOTALL
            ):
                try:
                    u = urlparse(href)
                    qs = dict(parse_qsl(u.query))
                    cid = qs.get('id') or ''
                except Exception:
                    cid = ''
                name = html.unescape((title_attr or link_text).strip())
                if cid:
                    chans.append({'channel_name': name, 'channel_id': cid})

            if chans:
                trns.append({'title': title, 'channels': chans})

        return trns

    except Exception as e:
        log(f'getTransData error for categ={categ}: {e}')
        return []

def TransList(categ, channels):
    for channel in channels:
        channel_title = html.unescape(channel.get('channel_name'))
        channel_id = str(channel.get('channel_id', '')).strip()
        if not channel_id:
            continue
        addDir(channel_title, build_url({'mode': 'trLinks', 'trData': json.dumps({'channels': [{'channel_name': channel_title, 'channel_id': channel_id}]})}), False)
    closeDir()

def getSource(trData):
    try:
        data = json.loads(unquote(trData))
        channels_data = data.get('channels')
        if channels_data and isinstance(channels_data, list):
            cid = str(channels_data[0].get('channel_id', '')).strip()
            if not cid:
                return
            xbmcplugin.setContent(addon_handle, 'videos')
            PlayStream(cid)
    except Exception as e:
        log(f'getSource failed: {e}')

def list_gen():
    chData = channels()
    for c in chData:
        addDir(c[1], build_url({'mode': 'play', 'url': abs_url(c[0])}), False)
    closeDir()

def channels():
    url = abs_url('24-7-channels.php')
    allow_adult = xbmcaddon.Addon().getSetting('adult_pw') == 'lol'
    headers = {'Referer': get_active_base(), 'User-Agent': UA}

    try:
        resp = requests.post(url, headers=headers, timeout=10).text
    except Exception as e:
        log(f"[DADDYLIVE] channels(): request failed: {e}")
        return []

    card_rx = re.compile(
        r'<a\s+class="card"[^>]*?href="(?P<href>[^"]+)"[^>]*?data-title="(?P<data_title>[^"]*)"[^>]*>'
        r'.*?<div\s+class="card__title">\s*(?P<title>.*?)\s*</div>'
        r'.*?ID:\s*(?P<id>\d+)\s*</div>'
        r'.*?</a>',
        re.IGNORECASE | re.DOTALL
    )

    items = []
    for m in card_rx.finditer(resp):
        href_rel = m.group('href').strip()
        title_dom = html.unescape(m.group('title').strip())
        title_attr = html.unescape(m.group('data_title').strip())
        name = title_dom or title_attr

        is_adult = ('18+' in name) or ('18+' in title_attr) or name.lower().startswith('18+')
        if is_adult and not allow_adult:
            continue

        name = re.sub(r'^\s*\d+(?=[A-Za-z])', '', name).strip()

        items.append([href_rel, name])

    if not items:
        log("[DADDYLIVE] channels(): Site may have changed.")

    return items

def decode_econfig(encoded):
    s = base64.b64decode(encoded).decode('utf-8')
    size = math.ceil(len(s) / 4)
    chunks = [s[i * size:(i + 1) * size] for i in range(4)]
    perm = [2, 0, 3, 1]
    reordered = [''] * 4
    for i in range(4):
        c = chunks[i]
        c = c[:3] + c[4:]
        reordered[perm[i]] = base64.b64decode(c).decode('utf-8')
    return json.loads(base64.b64decode(''.join(reordered)).decode('utf-8'))

def fetch_page(url, referer=None):
    headers = {'User-Agent': UA}
    if referer:
        headers['Referer'] = referer
    try:
        return requests.get(url, headers=headers, timeout=10).text
    except (requests.exceptions.ConnectionError, requests.exceptions.Timeout):
        time.sleep(0.4)
        return requests.get(url, headers=headers, timeout=10).text

def iframe_src(page, page_url):
    m = re.search(r'<iframe[^>]+src="([^"]+)"', page, re.I)
    if not m:
        return None
    return urljoin(page_url, html.unescape(m.group(1)).strip())

def resolve_cast(player_url, referer):
    embed_url = iframe_src(fetch_page(player_url, referer), player_url)
    if not embed_url:
        log(f'[resolve_cast] No iframe found: {player_url}')
        return None
    page = fetch_page(embed_url, player_url)
    stream_url = None
    m = re.search(r"window\._econfig='([^']+)'", page)
    if m:
        try:
            cfg = decode_econfig(m.group(1))
            stream_url = cfg.get('stream_url_nop2p') or cfg.get('stream_url')
        except Exception as e:
            log(f'[resolve_cast] _econfig decode failed: {e}')
    stream_url = stream_url or decode_payload(page)
    if not stream_url:
        log(f'[resolve_cast] No stream found: {embed_url}')
        return None
    return stream_url, embed_url

def decode_payload(page):
    m = re.search(r'(?:var|let|const)\s+\w+\s*=\s*\[([\d,\s]+)\]\s*,\s*\w+\s*=\s*(\d+)\s*,\s*\w+\s*=\s*(\d+)', page)
    if not m:
        return None
    key1 = int(m.group(2))
    key2 = int(m.group(3))
    decoded = ''.join(chr(((int(n) ^ key1) - key2 + 256) % 256) for n in m.group(1).split(','))
    m = re.search(r'SIGNED_URL\s*=\s*"([^"]+)"', decoded) or re.search(r'\burl\s*=\s*"([^"]+)"', decoded)
    if not m:
        return None
    return m.group(1).replace('\\/', '/')

def resolve_plus(player_url, referer):
    embed_url = iframe_src(fetch_page(player_url, referer), player_url)
    if not embed_url:
        log(f'[resolve_plus] No iframe found: {player_url}')
        return None
    stream_url = decode_payload(fetch_page(embed_url, player_url))
    if not stream_url:
        log(f'[resolve_plus] No stream url in payload: {embed_url}')
        return None
    return stream_url, embed_url

def resolve_casting(player_url, referer):
    outer_url = iframe_src(fetch_page(player_url, referer), player_url)
    if not outer_url:
        log(f'[resolve_casting] No iframe found: {player_url}')
        return None
    embed_url = iframe_src(fetch_page(outer_url, player_url), outer_url)
    if not embed_url:
        log(f'[resolve_casting] No inner iframe found: {outer_url}')
        return None
    m = re.search(r'const\s+streamUrls\s*=\s*(\[[^\]]*\])', fetch_page(embed_url, outer_url))
    if not m:
        log(f'[resolve_casting] No streamUrls found: {embed_url}')
        return None
    for entry in json.loads(m.group(1)):
        if isinstance(entry, dict):
            entry = next((entry[k] for k in ('url', 'src', 'file', 'stream_url') if isinstance(entry.get(k), str) and entry[k]), None)
        if isinstance(entry, str) and entry:
            return entry, embed_url
    log(f'[resolve_casting] No usable URL in streamUrls: {embed_url}')
    return None

def resolve_watch(player_url, referer):
    embed_url = iframe_src(fetch_page(player_url, referer), player_url)
    if not embed_url:
        log(f'[resolve_watch] No iframe found: {player_url}')
        return None
    m = re.search(r'const\s+SRC\s*=\s*"([^"]+)"', fetch_page(embed_url, player_url))
    if not m:
        log(f'[resolve_watch] No SRC found: {embed_url}')
        return None
    return m.group(1).replace('\\/', '/'), embed_url

def b64_url(encoded):
    try:
        text = base64.b64decode(encoded + '=' * (-len(encoded) % 4)).decode('utf-8', 'ignore')
    except Exception:
        return None
    m = re.search(r"atob\('([^']+)'\)", text)
    if m:
        return b64_url(m.group(1))
    m = re.search(r'(?:https?:)?//[^\s"\'<>]+', text)
    return m.group(0) if m else None

def next_hop(page, page_url):
    m = re.search(r'data-encoded="([^"]+)"', page)
    if m and b64_url(m.group(1)):
        return urljoin(page_url, b64_url(m.group(1)))
    m = re.search(r'"([A-Za-z0-9+/=]{40,})"\s*;\s*eval\(atob', page)
    if m and b64_url(m.group(1)):
        return urljoin(page_url, b64_url(m.group(1)))
    m = re.search(r"iframe\.src\s*=\s*'([^']+)'\s*\+\s*encodeURIComponent", page)
    if m:
        channel = re.sub(r'[/\\.?&=]', '', dict(parse_qsl(urlparse(page_url).query)).get('id', '').strip())
        if channel:
            return urljoin(page_url, m.group(1) + quote_plus(channel))
    m = re.search(r'f\.src\s*=\s*"([^"]+)"', page) or re.search(r'<ifr(?:\'\+\')?ame[^>]+src="((?:https?:)?//[^"]+)"', page, re.I)
    if m:
        return urljoin(page_url, html.unescape(m.group(1)).strip())
    return None

def resolve_player(player_url, referer):
    url = player_url
    for _ in range(10):
        page = fetch_page(url, referer)
        stream_url = decode_payload(page)
        if stream_url:
            return stream_url, url
        nxt = next_hop(page, url)
        if not nxt:
            log(f'[resolve_player] Chain ended without a stream: {url}')
            return None
        referer = None if 'referrerpolicy="no-referrer"' in page else normalize_origin(url)
        url = nxt
    log(f'[resolve_player] Chain too long: {player_url}')
    return None

PLAYERS = {'stream': resolve_watch, 'cast': resolve_cast, 'watch': resolve_watch, 'plus': resolve_plus, 'casting': resolve_casting, 'player': resolve_player}
PROXIED = ('stream', 'watch', 'plus', 'player')

def proxy_url(stream_url, headers, name):
    port = WINDOW.getProperty(PROXY_PORT_PROP)
    manifest_dir = WINDOW.getProperty(PROXY_DIR_PROP)
    if not port or not manifest_dir:
        log('[proxy_url] Segment proxy not running, playing direct.')
        return None
    manifest_id = f'{name}_{int(time.time() * 1000)}'
    with open(os.path.join(manifest_dir, f'{manifest_id}.json'), 'w', encoding='utf-8') as f:
        json.dump({'url': stream_url, 'headers': headers}, f)
    return f'http://127.0.0.1:{port}/manifest/{manifest_id}.m3u8'

def PlayStream(cid):
    try:
        watch_url = abs_url('watch.php?id=' + cid)
        buttons = re.findall(r'data-url="([^"]+)"\s+title="([^"]+)"', fetch_page(watch_url, get_active_base()))
        options = []
        for player_url, title in buttons:
            folder = urlparse(player_url).path.strip('/').split('/')[0]
            if folder in PLAYERS:
                options.append((html.unescape(title).strip().title(), urljoin(watch_url, html.unescape(player_url).strip()), folder))
        if not options:
            options.append(('Player 2', abs_url(f'cast/stream-{cid}.php'), 'cast'))
        if len(options) == 1:
            choice = 0
        else:
            choice = xbmcgui.Dialog().select('Choose Player', [o[0] for o in options])
        if choice == -1:
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
            return
        chosen = options[choice][0]
        result = None
        for label, player_url, folder in [options[choice]] + options[:choice] + options[choice + 1:]:
            try:
                result = PLAYERS[folder](player_url, watch_url)
            except Exception as e:
                log(f'[PlayStream] {label} raised: {e}')
            if result:
                break
            log(f'[PlayStream] {label} did not resolve, trying next')
        if not result:
            xbmcgui.Dialog().notification('Daddylive', 'No playable source', ICON, 3000)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
            return
        if label != chosen:
            xbmcgui.Dialog().notification('Daddylive', f'{chosen} unavailable, using {label}', ICON, 3000)
        stream_url, embed_url = result
        embed_origin = normalize_origin(embed_url).rstrip('/')
        header_dict = {
            'Referer': f'{embed_origin}/',
            'Origin': embed_origin,
            'User-Agent': UA,
        }
        local_url = proxy_url(stream_url, header_dict, folder) if folder in PROXIED else None
        if local_url:
            m3u8 = f'{local_url}|User-Agent={quote_plus(UA)}'
        else:
            header_str = '&'.join(f'{k}={quote_plus(v)}' for k, v in header_dict.items())
            m3u8 = f'{stream_url}|{header_str}'
        log(f'[PlayStream] {label} Final HLS = {m3u8}')
        liz = xbmcgui.ListItem('Daddylive', path=m3u8)
        liz.setProperty('inputstream', 'inputstream.ffmpegdirect')
        liz.setMimeType('application/x-mpegURL')
        liz.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
        liz.setProperty('inputstream.ffmpegdirect.stream_mode', 'timeshift')
        liz.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')
        xbmcplugin.setResolvedUrl(addon_handle, True, liz)
    except Exception as e:
        import traceback
        log(f"[PlayStream] Exception: {e}\n{traceback.format_exc()}")
        try:
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        except Exception:
            pass

def Search_Events():
    keyboard = xbmcgui.Dialog().input("Enter search term", type=xbmcgui.INPUT_ALPHANUM)
    if not keyboard or keyboard.strip() == '':
        return
    term = keyboard.lower().strip()

    try:
        base = get_active_base()
        headers = {'User-Agent': UA, 'Referer': base}
        html_text = requests.get(abs_url('index.php'), headers=headers, timeout=10).text

        events = re.findall(
            r"<div\s+class=\"schedule__event\">.*?"
            r"<div\s+class=\"schedule__eventHeader\"[^>]*?>\s*"
            r"(?:<[^>]+>)*?"
            r"<span\s+class=\"schedule__time\"[^>]*data-time=\"([^\"]+)\"[^>]*>.*?</span>\s*"
            r"<span\s+class=\"schedule__eventTitle\">\s*([^<]+)\s*</span>.*?"
            r"</div>\s*"
            r"<div\s+class=\"schedule__channels\">(.*?)</div>",
            html_text, re.IGNORECASE | re.DOTALL
        )

        rows = {}
        seen = set()
        for time_str, raw_title, channels_block in events:
            title_clean = html.unescape(raw_title.strip())
            if term not in title_clean.lower():
                continue

            local_ts = get_local_time(time_str.strip())
            row_title = f"[COLOR gold]{local_ts}[/COLOR] {title_clean}"

            for href, title_attr, link_text in re.findall(
                r"<a[^>]+href=\"([^\"]+)\"[^>]*title=\"([^\"]*)\"[^>]*>(.*?)</a>",
                channels_block, re.IGNORECASE | re.DOTALL
            ):
                try:
                    u = urlparse(href)
                    qs = dict(parse_qsl(u.query))
                    cid = (qs.get('id') or '').strip()
                except Exception:
                    cid = ''
                if not cid:
                    continue

                sig = (title_clean.lower(), time_str.strip(), cid)
                if sig in seen:
                    continue
                seen.add(sig)

                ch_name = html.unescape((title_attr or link_text or '').strip()) or 'Channel'
                rows.setdefault(row_title, [])
                if all(cid != c['channel_id'] for c in rows[row_title]):
                    rows[row_title].append({'channel_name': ch_name, 'channel_id': cid})

        if not rows:
            xbmcgui.Dialog().ok("Search", "No matching events found.")
            return

        for row_title, chans in rows.items():
            addDir(row_title, build_url({'mode': 'trList', 'trType': 'search', 'channels': json.dumps(chans)}), True)
        closeDir()

    except Exception as e:
        log(f"Search_Events (fast) error: {e}")
        xbmcgui.Dialog().ok("Search", "Search failed. Check log.")

def Search_Channels():
    keyboard = xbmcgui.Dialog().input("Enter channel name", type=xbmcgui.INPUT_ALPHANUM)
    if not keyboard or keyboard.strip() == '':
        return
    term = keyboard.lower().strip()

    try:
        base = get_active_base()
        headers = {'User-Agent': UA, 'Referer': base}
        html_text = requests.get(abs_url('index.php'), headers=headers, timeout=10).text

        channel_blocks = re.findall(
            r"<div\s+class=\"schedule__event\">.*?"
            r"<div\s+class=\"schedule__eventHeader\"[^>]*?>.*?</div>\s*"
            r"<div\s+class=\"schedule__channels\">(.*?)</div>",
            html_text, re.IGNORECASE | re.DOTALL
        )

        results = []
        seen = set()
        for block in channel_blocks:
            for href, title_attr, link_text in re.findall(
                r"<a[^>]+href=\"([^\"]+)\"[^>]*title=\"([^\"]*)\"[^>]*>(.*?)</a>",
                block, re.IGNORECASE | re.DOTALL
            ):
                display = html.unescape((title_attr or link_text or '').strip())
                if term not in display.lower():
                    continue

                try:
                    u = urlparse(href)
                    qs = dict(parse_qsl(u.query))
                    cid = (qs.get('id') or '').strip()
                except Exception:
                    cid = ''
                if not cid:
                    continue

                sig = (display.lower(), cid)
                if sig in seen:
                    continue
                seen.add(sig)

                results.append({'title': display, 'channel_id': cid})

        if not results:
            xbmcgui.Dialog().ok("Search", "No matching channels found.")
            return

        for result in results:
            addDir(result['title'], build_url({
                'mode': 'trLinks',
                'trData': json.dumps({'channels': [{'channel_name': result["title"], 'channel_id': result["channel_id"]}]})
            }), False)
        closeDir()

    except Exception as e:
        log(f"Search_Channels (fast) error: {e}")
        xbmcgui.Dialog().ok("Search", "Search failed. Check log.")

def refresh_active_base():
    new_base = resolve_active_baseurl(SEED_BASEURL)
    set_active_base(new_base)
    xbmcgui.Dialog().ok("Daddylive", f"Active domain set to:\n{new_base}")
    xbmc.executebuiltin('Container.Refresh')

kodiversion = getKodiversion()
mode = params.get('mode', None)

if not mode:
    Main_Menu()
else:
    if mode == 'menu':
        servType = params.get('serv_type')
        if servType == 'sched':
            Menu_Trans()
        elif servType == 'live_tv':
            list_gen()
        elif servType == 'search':
            Search_Events()
        elif servType == 'search_channels':
            Search_Channels()
        elif servType == 'refresh_sched':
            xbmc.executebuiltin('Container.Refresh')
        elif servType == 'resolve_base_now':
            refresh_active_base()

    elif mode == 'showChannels':
        transType = params.get('trType')
        channels = getTransData(transType)
        ShowChannels(transType, channels)

    elif mode == 'trList':
        transType = params.get('trType')
        channels = json.loads(params.get('channels'))
        TransList(transType, channels)

    elif mode == 'trLinks':
        trData = params.get('trData')
        getSource(trData)

    elif mode == 'play':
        link = params.get('url')
        cid = dict(parse_qsl(urlparse(link).query)).get('id', '').strip()
        if cid:
            PlayStream(cid)

    elif mode == 'resolve_base_now':
        refresh_active_base()
