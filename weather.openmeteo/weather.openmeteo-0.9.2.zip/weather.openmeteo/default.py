import sys
from lib import weather

if (__name__ == '__main__'):
	weather.Main(sys.argv[1])
