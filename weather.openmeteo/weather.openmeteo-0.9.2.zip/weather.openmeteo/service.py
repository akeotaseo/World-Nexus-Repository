from lib import service

if (__name__ == '__main__'):
	service.Main()

