import xbmc, xbmcgui


def Arrownegra():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10, click_11, click_12, click_13, click_14, click_15, click_16, click_17, click_18, click_19, click_20, click_21)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]  ~ ArrowNegra ~[/COLOR][/B]', 
['[B][COLOR=white]X-codes[/COLOR][/B]',
 '[COLOR maroon]ÁGUIA[/COLOR] [COLOR gold]BRANCA[/COLOR] (PORTAL)',
 '[COLOR red]Águia[/COLOR] [COLOR yellow]Negra[/COLOR] (MULTI)',
 '[COLOR red]Flecha[/COLOR] [COLOR grey]Negra[/COLOR] (MULTI)',
 '[COLOR red]Águia [COLOR grey]de [COLOR gold]Ouro[/COLOR] (SPORTS)',
 '[COLOR grey]Black [COLORorange]Truck[/COLOR] (CANAIS)',
 '[COLORlime]steel[/COLOR] [COLORmaroon]eagle[/COLOR] (CANAIS)',
 '[COLORlime]Vultur[/COLOR] [COLORmaroon]foc[/COLOR] (CANAIS)',
 '[COLORgrey]Águia [COLORbrown]Real[/COLOR] (CANAIS)',
 '[COLORred]Águia [COLORwhite]Vavoo[/COLOR]',
 '[COLOR grey]fenix [COLORorange]portal[/COLOR] (CANAIS-VOD)',
 '[COLORcyan]Fenix [COLORgrey]Mac[/COLOR]...',
 '[COLORgrey]ArrowNegra[/COLOR] [COLORred]Play[/COLOR] [COLORcyan]Tv[/COLOR] (Playlist Loader)',
 'ArrowLSP (LiveStreamsPro)',
 '[COLORgrey]ArrowNegra[/COLOR] [COLORred]Play[/COLOR] [COLORcyan]Tv[/COLOR] (iptv-org)',
 '[COLOR orange]K-PT[/COLOR] (CANAIS)',
 '[COLORorange]Infinity[/COLOR] (CANAIS)',
 '[COLORlime]black[/COLOR] [COLORmaroon]arrow18[/COLOR]'
 ])
 #'[B][COLOR orchid]¤[/COLOR] [B][COLOR white]LIVE CHANNELS[/COLOR] [COLOR orchid] (DL)[/COLOR] [COLOR orchid]¤[/COLOR][/B] (THE CREW)',


    if call:
        if call < 0:
            return
        func = funcs[call-21]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.autowidget/folders/py/Arrownegra/x-codes.py")')

def click_2():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.autowidget/folders/py/Arrownegra/aguia-branca.py")')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.aguianegra/",return)')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.flechanegra/",return)')
    
def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.aguia_de_ouro/",return)')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.Black_Truck/",return)')
    
def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.steel_eagle/",return)')

def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.vultur.de.foc/",return)')

def click_9():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.aguia_real/",return)')
    
def click_10():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.aguiavavoo/",return)')

def click_11():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.fenix.portal/",return)')

def click_12():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.fenix-mac/",return)')

def click_13():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.arrownegra.play.tv/",return)')
    
def click_14():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.arrow.lsp/",return)')
    
def click_15():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.arrownegra.play.tv/",return)')
    
def click_16():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.K-PT/",return)')

def click_17():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.infinity/",return)')
    
def click_18():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.blackarrow18/",return)')
    
def click_19():
    xbmc.executebuiltin('   ')
    
def click_20():
    xbmc.executebuiltin('   ')
    
def click_21():
    xbmc.executebuiltin('   ')


Arrownegra()
