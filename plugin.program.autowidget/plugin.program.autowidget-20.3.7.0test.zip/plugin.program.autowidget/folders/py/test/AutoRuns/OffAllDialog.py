﻿import os, xbmc, xbmcvfs, xbmcgui


def OffAll():
        choice = xbmcgui.Dialog().yesno('[COLOR orange]Τερματισμός όλων των υπηρεσιών[/COLOR]', 'Με αυτή την επιλογή θα γίνει Τερματισμός όλων των υπηρεσιών ([COLOR red] Netflix[/COLOR] - [COLOR silver] Elementum[/COLOR] κ.α).[CR]Στην επόμενη εκκίνηση του kodi οι [B]Υπηρεσίες[/B] θα ενεργοποιηθουν ξανά..[CR][CR]Θέλετε να συνεχίσετε ?',
                                        nolabel='[B][COLOR white]Όχι[/COLOR][/B]',yeslabel='[B][COLOR red]Ναι[/COLOR][/B]')

        if choice == 1: [xbmc.executebuiltin('ActivateWindow(10001,"plugin://plugin.program.downloader/stopservice")'),]


OffAll()
