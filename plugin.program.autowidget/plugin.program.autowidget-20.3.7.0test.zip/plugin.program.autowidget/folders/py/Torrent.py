import xbmc, xbmcgui


def torrent():
    funcs = (click_1, click_2, click_3)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]Elementum[/COLOR][/B]', 
['[COLOR=orange]Elementum[/COLOR]',
 'Elementum [COLOR FFFF6B00]Burst[/COLOR]*',
 '[B][COLOR orange]Install Elementum[/COLOR][/B]'])
 



    if call:
        if call < 0:
            return
        func = funcs[call-3]
        return func()
    else:
        func = funcs[call]
        return func()
    return 




#def click_1():
#    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.apex_sports/?category=live_sport&amp;mode=search)')
#    xbmcgui.Dialog().notification("[B][COLOR orange]TechNEWSology[/COLOR][/B]",'[COLOR white]Για την αναζήτηση αγώνων, πληκτρολογήστε την Ομάδα ή την Χώρα με λατινικούς χαρακτήρες ...[/COLOR]' , icon ='special://home/addons/skin.TechNEWSology/icon.png')

def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.elementum/")')
    
def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.elementum/settings/script.elementum.burst")')
    
def click_3():
    xbmc.executebuiltin('ActivateWindow(10001,"plugin://plugin.program.installelementum/?description&fanart&iconimage&mode=3&name=%5bB%5dElementum%5b%2fB%5d&setaddon&skin&url")')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.romanianpack/?action=openCinemagia&meniu=all&url=https%3a%2f%2fwww.cinemagia.ro%2ffilme%2f%3fpn%3d1")')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.romanianpack/?action=openCinemagia&meniu=ani&url=https%3a%2f%2fwww.cinemagia.ro%2ffilme%2f%3fpn%3d1")')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.romanianpack/?action=openCinemagia&meniu=gen&url=https%3a%2f%2fwww.cinemagia.ro%2ffilme%2f%3fpn%3d1")')

def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.romanianpack/?action=openCinemagia&meniu=tari&url=https%3a%2f%2fwww.cinemagia.ro%2ffilme%2f%3fpn%3d1")')

def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.romanianpack/?action=openCinemagia&meniu=all&url=https%3a%2f%2fwww.cinemagia.ro%2fseriale-tv%2f%3fpn%3d1")')

def click_9():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.romanianpack/?action=openCinemagia&meniu=ani&url=https%3a%2f%2fwww.cinemagia.ro%2fseriale-tv%2f%3fpn%3d1")')

def click_10():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.romanianpack/?action=openCinemagia&meniu=gen&url=https%3a%2f%2fwww.cinemagia.ro%2fseriale-tv%2f%3fpn%3d1")')

def click_11():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.romanianpack/?action=openCinemagia&meniu=tari&url=https%3a%2f%2fwww.cinemagia.ro%2ffilme%2f%3fpn%3d1")')

torrent()
