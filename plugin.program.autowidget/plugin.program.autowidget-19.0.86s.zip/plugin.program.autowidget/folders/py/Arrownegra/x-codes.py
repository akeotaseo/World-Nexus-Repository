import xbmc, xbmcgui


def xcodes():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ x-codes ~[/COLOR][/B]', 
['[COLOR chocolate]X[/COLOR][COLORwhite]-[/COLOR][COLORgold]Codes[/COLOR]',
 '[COLORorange]Pach API -Codes[/COLOR]',
 #'    ',
 #'[B][COLOR red]neo[/COLOR][COLOR orange]tv [/COLOR][/B] (F4mtester)',
 #'IPTV Stalker',
 #'[COLOR white]XC MAC M3U[/COLOR]'
 
 ])


    if call:
        if call < 0:
            return
        func = funcs[call-6]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.x-codes/",return)')

def click_2():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.autowidget/folders/py/Arrownegra/DialogX-codes.py")')

def click_3():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.autowidget/folders/py/Arrownegra/x-codes.py")')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.neo.tv/",return)')
    
def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.stalker/",return)')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.macvod/",return)')

xcodes()
