﻿import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob

def fixbuildin():
        choice = xbmcgui.Dialog().yesno('[COLOR orange]Διαγραφή addon data downloader19[/COLOR]', 'Με αυτή την επιλογή θα διαγραφούν οι ρυθμίσεις του [COLOR orange]downloader19[/COLOR] και θα πραγματοποιηθεί επαναφόρτωση του προφίλ, με αποτέλεσμα να παγώσει για λίγα δευτερόλεπτα η εικόνα.[CR]Στην συνέχεια θα εγκατασταθούν (ξανά) οι νέες ενημερώσεις του build.[CR][CR]Για να συνεχίσετε πατήστε [B][COLOR green]Διαγραφή[/COLOR][/B][CR]και περιμένετε...',
                                        nolabel='[B][COLOR white]Όχι τώρα...[/COLOR][/B]',yeslabel='[B][COLOR green]Διαγραφή[/COLOR][/B]')

        if choice == 1: [xbmcvfs.delete('special://home/addons/plugin.program.downloader19/downloader_startup.py'), 
                         xbmc.sleep(1000),
                         xbmcvfs.delete('special://home/userdata/addon_data/plugin.program.downloader19/settings.xml'),
                         xbmc.sleep(1000),
                         xbmc.executebuiltin('RunScript("special://home/addons/service.World.Build/PY/UpdaterMatrixDelete.py")'),
                         xbmc.sleep(1000),
                         xbmcgui.Dialog().notification("[B][COLOR orange]Διαγραφή με επιτυχία ![/COLOR][/B]", "[COLOR white]Αναμονή για Reload Profile...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/rp.png'),
                         xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=forceprofile)'),
                         xbmc.sleep(2000),
                         xbmcgui.Dialog().notification("[B][COLOR orange]Reload Profile[/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/reloadprofile.png'),]

fixbuildin()
