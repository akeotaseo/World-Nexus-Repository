﻿import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob

def DialogEnableDisabledownloaderstartup():        
        choice = xbmcgui.Dialog().yesno('[COLOR orange]Pach API Aguia_Branca Stalker[/COLOR]', '[CR]Με την εκτέλεση του [COLOR yellow][B][COLORorange]Pach API Aguia_Branca Stalker[/COLOR][/B][/COLOR], θα ανοίξει παράθυρο διαλόγου... και το kodi θα κλείσει άμεσα.[CR][CR]Για να συνεχίσετε πατήστε [B][COLORorange]Pach API Aguia_Branca Stalker[/COLOR][/B]',
                                        nolabel='[B][COLOR white]Όχι τώρα...[/COLOR][/B]',yeslabel='[B][COLORorange]Pach API Aguia_Branca Stalker[/COLOR][/B]')
                                        
        if choice == 1: [xbmc.executebuiltin('ActivateWindow(10001,"plugin://script.aguia-branca.api.stalker/",return)'),
                        ]
                         
DialogEnableDisabledownloaderstartup()
