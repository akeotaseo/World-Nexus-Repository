import xbmc, xbmcgui


def search():
    funcs = (click_1, click_2)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]Search[/COLOR][/B]', 
['[B][COLOR=white]Search [COLOR=blue]Movies [/COLOR][/B]',
 '[B][COLOR=white]Search [COLOR=green]Series [/COLOR][/B]'])


    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 




#def click_1():
#    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.apex_sports/?category=live_sport&amp;mode=search)')
#    xbmcgui.Dialog().notification("[B][COLOR orange]TechNEWSology[/COLOR][/B]",'[COLOR white]Για την αναζήτηση αγώνων, πληκτρολογήστε την Ομάδα ή την Χώρα με λατινικούς χαρακτήρες ...[/COLOR]' , icon ='special://home/addons/skin.TechNEWSology/icon.png')

def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.autowidget/?group=07search_movies-07&mode=group&refresh&reload")')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.autowidget/?group=08search_series-08&mode=group&refresh&reload")')

search()
