﻿import xbmc



xbmc.executebuiltin('ActivateWindow(10502,"plugin://plugin.audio.eradio.gr/?action=radios&title=Sophisticated&url=http%3a%2f%2feradio.mobi%2fcache%2f1%2f1%2fmedialist_categoryID11.json",return)')