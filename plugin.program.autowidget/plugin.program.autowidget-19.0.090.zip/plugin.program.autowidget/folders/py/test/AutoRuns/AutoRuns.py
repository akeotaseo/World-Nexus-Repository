import xbmc, xbmcgui


def AutoRuns():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ AutoRuns~[/COLOR][/B]', 
['[B][COLOR=white]Autoruns[/COLOR][/B]',
 '[B][COLOR=white]Τερματισμός όλων των υπηρεσιών[/COLOR][/B]',
 '[B][COLOR=white]Netflix [B][COLOR gold](Disabled)[/COLOR][/B]',
 '[B][COLOR=white]Netflix [B][COLOR lime](Enabled)[/COLOR][/B]',
 '[B][COLOR=white]Xrysoi - Παιδικά Μεταγλωτισμένα[/COLOR][/B] (mj-cartoonsgr)',
 '[B][COLOR=white]Xrysoi - Παιδικά Υπότιτλοι[/COLOR][/B] (mj-cartoonsgr)',
 '[B][COLOR=white]Ζωντανή Τηλεόραση[/COLOR][/B] (AliveGR)',
 '[B][COLOR=white]Sophisticated[/COLOR][/B] (eradio)',
 '[B][COLOR=white]Αναζήτηση[/COLOR][/B] (YouTube)'])


    if call:
        if call < 0:
            return
        func = funcs[call-9]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10001,"plugin://script.autoruns/",return)')

def click_2():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.autowidget/folders/py/AutoRuns/OffAllDialog.py")')

def click_3():
    xbmc.executebuiltin('PlayMedia("plugin://script.autoruns/?path=C%3A%5CPortableApps%5Ckodi%5CMy+kodi%5CKodi%5Cportable_data%5Caddons%5Cplugin.video.netflix%7Cservice.py&mode=1&name=Netflix+%5BB%5D%5BCOLOR+lime%5D%28Enabled%29%5B%2FCOLOR%5D%5B%2FB%5D")')

def click_4():
    xbmc.executebuiltin('PlayMedia("plugin://script.autoruns/?path=C%3A%5CPortableApps%5Ckodi%5CMy+kodi%5CKodi%5Cportable_data%5Caddons%5Cplugin.video.netflix%7Cservice.py.disabled&mode=1&name=Netflix+%5BB%5D%5BCOLOR+gold%5D%28Disabled%29%5B%2FCOLOR%5D%5B%2FB%5D")')
    
def click_5():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.autowidget/folders/py/Quickly/5.py")')

def click_6():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.autowidget/folders/py/Quickly/6.py")')

def click_7():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.autowidget/folders/py/Quickly/7.py")')

def click_8():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.autowidget/folders/py/Quickly/8.py")')

def click_9():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.autowidget/folders/py/Quickly/9.py")')

AutoRuns()
