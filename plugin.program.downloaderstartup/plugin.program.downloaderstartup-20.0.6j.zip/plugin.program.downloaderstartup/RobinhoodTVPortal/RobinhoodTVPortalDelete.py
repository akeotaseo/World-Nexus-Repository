import os, xbmc, xbmcvfs, xbmcgui, shutil, glob

base_path = xbmcvfs.translatePath('special://home/addons')



dir_list = glob.iglob(os.path.join(base_path, "plugin.video.balkanclient"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)

dir_list = glob.iglob(os.path.join(base_path, "plugin.video.worldclient"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)

dir_list = glob.iglob(os.path.join(base_path, "plugin.video.worldclient2"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)

dir_list = glob.iglob(os.path.join(base_path, "plugin.video.worldclient3"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)


dir_list = glob.iglob(os.path.join(base_path, "plugin.video.x-codes2"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)


dir_list = glob.iglob(os.path.join(base_path, "plugin.video.x-codes-x"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)




#############################################################################

base_path = xbmcvfs.translatePath('special://home/userdata/addon_data')



dir_list = glob.iglob(os.path.join(base_path, "plugin.video.balkanclient"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)

dir_list = glob.iglob(os.path.join(base_path, "plugin.video.worldclient"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)

dir_list = glob.iglob(os.path.join(base_path, "plugin.video.worldclient2"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)

dir_list = glob.iglob(os.path.join(base_path, "plugin.video.worldclient3"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)


dir_list = glob.iglob(os.path.join(base_path, "plugin.video.x-codes2"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)


dir_list = glob.iglob(os.path.join(base_path, "plugin.video.x-codes-x"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)




dir_list = glob.iglob(os.path.join(base_path, "plugin.video.edemro"))
for path in dir_list:
    if os.path.isdir(path):
        shutil.rmtree(path)

