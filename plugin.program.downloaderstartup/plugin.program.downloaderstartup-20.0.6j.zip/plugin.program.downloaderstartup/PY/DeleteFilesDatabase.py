﻿import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob

def DeleteFilesDatabase():


#    xbmcvfs.delete('special://home/userdata/addon_data/plugin.program.downloader19/Database_Addons33.py')

    base_path = xbmcvfs.translatePath('special://home/userdata/addon_data/plugin.program.downloader19')

    dir_list = glob.iglob(os.path.join(base_path, "__pycache__"))
    for path in dir_list:
        if os.path.isdir(path):
            shutil.rmtree(path)


DeleteFilesDatabase()
