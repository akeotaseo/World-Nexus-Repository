import xbmc, xbmcgui


def mypreferences():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10, click_11, click_12, click_13, click_14,
             click_15, click_16, click_17)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]My Preferences[/COLOR][/B]', 
['[B]TAINIES[/B]',
 '[B]THL. SEIRES[/B]',
 '[B]ELLINIKA[/B]',
 '[B]WORLD TV[/B]',
 '[B]SPOR[/B]',
 '[B]NTOKYMANTEP[/B]',
 '[B]PAIDIKA[/B]',
 '[B]MOYSIKH[/B]',
 '[B]SYSTHMA[/B]',
 '[B]MY GROUPS[/B]',
 '[B]ALL IN ONE[/B]',
 '[B]KANALIA[/B]',
 '[B]FAVORITES[/B]',
 '[B]YOUTUBE[/B]',
 '[B]XXX[/B]',
 '[B]Downloads[/B]',



 '[B]                                                                                             [COLOR grey]Back[/COLOR][/B]'])
    if call:
        if call < 0:
            return
        func = funcs[call-17]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


def click_1():
    xbmc.executebuiltin("Action(Close)")
    xbmc.sleep(500)
    xbmc.executebuiltin('ActivateWindow(Videos,"plugin://plugin.program.mypreferences/?label=1.TAINIES TV&mode=400&path=special%3A%2F%2Fprofile%2Faddon_data%2Fplugin.program.mypreferences%5C1.TAINIES")')

def click_2():
    xbmc.executebuiltin("Action(Close)")
    xbmc.sleep(500)
    xbmc.executebuiltin('ActivateWindow(Videos,"plugin://plugin.program.mypreferences/?label=2.THL.SEIRES TV&mode=400&path=special%3A%2F%2Fprofile%2Faddon_data%2Fplugin.program.mypreferences%5C2.THL.SEIRES")')

def click_3():
    xbmc.executebuiltin("Action(Close)")
    xbmc.sleep(500)
    xbmc.executebuiltin('ActivateWindow(Videos,"plugin://plugin.program.mypreferences/?label=3.ELLINIKA TV&mode=400&path=special%3A%2F%2Fprofile%2Faddon_data%2Fplugin.program.mypreferences%5C3.ELLINIKA")')

def click_4():
    xbmc.executebuiltin("Action(Close)")
    xbmc.sleep(500)
    xbmc.executebuiltin('ActivateWindow(Videos,"plugin://plugin.program.mypreferences/?label=4.WORLD TV TV&mode=400&path=special%3A%2F%2Fprofile%2Faddon_data%2Fplugin.program.mypreferences%5C4.WORLD TV")')

def click_5():
    xbmc.executebuiltin("Action(Close)")
    xbmc.sleep(500)
    xbmc.executebuiltin('ActivateWindow(Videos,"plugin://plugin.program.mypreferences/?label=5.SPOR TV&mode=400&path=special%3A%2F%2Fprofile%2Faddon_data%2Fplugin.program.mypreferences%5C5.SPOR")')
    
def click_6():
    xbmc.executebuiltin("Action(Close)")
    xbmc.sleep(500)
    xbmc.executebuiltin('ActivateWindow(Videos,"plugin://plugin.program.mypreferences/?label=6.NTOKYMANTEPTV&mode=400&path=special%3A%2F%2Fprofile%2Faddon_data%2Fplugin.program.mypreferences%5C6.NTOKYMANTEP")')
    

def click_7():
    xbmc.executebuiltin("Action(Close)")
    xbmc.sleep(500)
    xbmc.executebuiltin('ActivateWindow(Videos,"plugin://plugin.program.mypreferences/?label=7.PAIDIKATV&mode=400&path=special%3A%2F%2Fprofile%2Faddon_data%2Fplugin.program.mypreferences%5C7.PAIDIKA")')  

def click_8():
    xbmc.executebuiltin("Action(Close)")
    xbmc.sleep(500)
    xbmc.executebuiltin('ActivateWindow(Videos,"plugin://plugin.program.mypreferences/?label=3.8.MOYSIKH TV&mode=400&path=special%3A%2F%2Fprofile%2Faddon_data%2Fplugin.program.mypreferences%5C8.MOYSIKH")')  

def click_9():
    xbmc.executebuiltin("Action(Close)")
    xbmc.sleep(500)
    xbmc.executebuiltin('ActivateWindow(Videos,"plugin://plugin.program.mypreferences/?label=9.SYSTHMA TV&mode=400&path=special%3A%2F%2Fprofile%2Faddon_data%2Fplugin.program.mypreferences%5C9.SYSTHMA")')

def click_10():
    xbmc.executebuiltin("Action(Close)")
    xbmc.sleep(500)
    xbmc.executebuiltin('ActivateWindow(Videos,"plugin://plugin.program.mypreferences/?label=10.MY GROUPS TV&mode=400&path=special%3A%2F%2Fprofile%2Faddon_data%2Fplugin.program.mypreferences%5C10.MY GROUPS")')

def click_11():
    xbmc.executebuiltin("Action(Close)")
    xbmc.sleep(500)
    xbmc.executebuiltin('ActivateWindow(Videos,"plugin://plugin.program.mypreferences/?label=11.ALL IN ONE TV&mode=400&path=special%3A%2F%2Fprofile%2Faddon_data%2Fplugin.program.mypreferences%5C11.ALL IN ONE")')

def click_12():
    xbmc.executebuiltin("Action(Close)")
    xbmc.sleep(500)
    xbmc.executebuiltin('ActivateWindow(Videos,"plugin://plugin.program.mypreferences/?label=12.KANALIA TV&mode=400&path=special%3A%2F%2Fprofile%2Faddon_data%2Fplugin.program.mypreferences%5C12.KANALIA")')

def click_13():
    xbmc.executebuiltin("Action(Close)")
    xbmc.sleep(500)
    xbmc.executebuiltin('ActivateWindow(Videos,"plugin://plugin.program.mypreferences/?13.FAVORITES TV&mode=400&path=special%3A%2F%2Fprofile%2Faddon_data%2Fplugin.program.mypreferences%5C13.FAVORITES")')

def click_14():
    xbmc.executebuiltin("Action(Close)")
    xbmc.sleep(500)
    xbmc.executebuiltin('ActivateWindow(Videos,"plugin://plugin.program.mypreferences/?label=14.YOUTUBE TV&mode=400&path=special%3A%2F%2Fprofile%2Faddon_data%2Fplugin.program.mypreferences%5C14.YOUTUBE")')

def click_15():
    xbmc.executebuiltin("Action(Close)")
    xbmc.sleep(500)
    xbmc.executebuiltin('ActivateWindow(Videos,"plugin://plugin.program.mypreferences/?label=15.XXX TV&mode=400&path=special%3A%2F%2Fprofile%2Faddon_data%2Fplugin.program.mypreferences%5C15.XXX")')

def click_16():
    xbmc.executebuiltin("Action(Close)")
    xbmc.sleep(500)
    xbmc.executebuiltin('ActivateWindow(Videos,"plugin://plugin.program.mypreferences/?label=16.Downloads TV&mode=400&path=special%3A%2F%2Fprofile%2Faddon_data%2Fplugin.program.mypreferences%5C16.Downloads")')

def click_17():
    xbmc.executebuiltin('ActivateWindow(Favouritesbrowser)')

mypreferences()
