import xbmc, xbmcgui


def wolf():
    funcs = (click_1, click_2, click_3, click_4, click_5)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ Wolf ~[/COLOR][/B]', 
['[B][COLOR=purple]---Διαγραφή The Crew---[/B][B][COLOR purple][/COLOR][/B]',
 '[B][COLOR=cyan]Wolf Pack[/COLOR][/B]',
 '[B][COLOR yellow]Big Bad Wolf[/COLOR][/B]',
 '[B][COLOR=grey]Madhouse[/COLOR][/B]',
 '[B][COLOR=firebrick]No Lives Matter[/COLOR][/B]'])


    if call:
        if call < 0:
            return
        func = funcs[call-5]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/AddonsDelete/DeleteTheCrew/DeleteTheCrew.py")')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.wolfpack)')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.bigbadwolf)')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.madhouse/",return)')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.nlm)')

wolf()
