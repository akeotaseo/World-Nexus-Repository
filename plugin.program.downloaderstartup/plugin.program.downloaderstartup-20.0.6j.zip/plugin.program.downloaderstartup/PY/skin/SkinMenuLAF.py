import xbmc, xbmcgui


def SkinMenuLAF():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7)
    call = xbmcgui.Dialog().select('[B]SkinMenuLAF[/B]', 
['[COLOR red] Skin [/COLOR] Text',
 '[COLOR red] Skin [/COLOR] Graph',
 '[COLOR red] Skin [/COLOR] GraphFocused',
 '[COLOR red] Skin [/COLOR] Ρυθμίσεις',
 '[COLOR red] Skin [/COLOR] Επαναφόρτωση',
 '[COLOR=red]Skin [/COLOR] Αλλαγή',
 '[COLOR red] Skin [/COLOR] Menu Settings'
 ])
 



    if call:
        if call < 0:
            return
        func = funcs[call-7]
        return func()
    else:
        func = funcs[call]
        return func()
    return 




#def click_1():
#    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.apex_sports/?category=live_sport&amp;mode=search)')
#    xbmcgui.Dialog().notification("[B][COLOR orange]TechNEWSology[/COLOR][/B]",'[COLOR white]Για την αναζήτηση αγώνων, πληκτρολογήστε την Ομάδα ή την Χώρα με λατινικούς χαρακτήρες ...[/COLOR]' , icon ='special://home/addons/skin.TechNEWSology/icon.png')

def click_1():
    xbmc.executebuiltin('Skin.Reset(MenuLAF)')
    xbmc.executebuiltin("ReloadSkin()")

def click_2():
    xbmc.executebuiltin('Skin.SetString(MenuLAF,Graph)')
    xbmc.executebuiltin("ReloadSkin()")

def click_3():
    xbmc.executebuiltin('Skin.SetString(MenuLAF,GraphFocused)')
    xbmc.executebuiltin("ReloadSkin()")

def click_4():
    xbmc.executebuiltin('ActivateWindow(SkinSettings),return')

def click_5():
    xbmc.executebuiltin("ReloadSkin()")

def click_6():
    xbmc.executebuiltin('PlayMedia("plugin://script.skinswitcher/?url=url&mode=1&name=Click+here+to+change+skins+&iconimage=C%3A%5CPortableApps%5Ckodi%5Ckodi+World+20%5CKodi%5Cportable_data%5Caddons%5Cscript.skinswitcher%5Cicon.png&fanart=C%3A%5CPortableApps%5Ckodi%5Ckodi+World+20%5CKodi%5Cportable_data%5Caddons%5Cscript.skinswitcher%5Cfanart.jpg")')

def click_7():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/skin/SkinMenuLAFSelect.py")')


SkinMenuLAF()
