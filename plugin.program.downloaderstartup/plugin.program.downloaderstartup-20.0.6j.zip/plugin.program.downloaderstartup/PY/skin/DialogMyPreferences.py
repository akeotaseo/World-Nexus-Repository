import os, xbmc, xbmcgui, glob, shutil

def addon_disable():
        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]MyPreferences[/COLOR][/B]', '[COLOR red] Προσοχή![/COLOR]  [COLOR white]Με αυτή την επιλογή θα γίνει διαγραφή των συντομεύσεων σε όλες τις κατηγορίες στις [/COLOR] [COLOR orange]Προτιμήσεις[/COLOR]',
                                        nolabel='[COLOR white]OXI[/COLOR]',yeslabel='[COLOR red]ΔΙΑΓΡΑΦΗ[/COLOR]')

        if choice == 1: xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/UpdaterMatrix_9.py'),

addon_disable()
