﻿import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob

def DialogCocoScrapers():
        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]Coco Scrapers[/COLOR][/B]', 'Για να λειτουργήσουν τα πρόσθετα [B][COLOR white]Umbrella, Fen κ.α[/COLOR][/B][CR]πρέπει να γίνει εγκατάσταση των[CR][B]Coco Scrapers[/B][CR]Για να συνεχίσετε πατήστε [B][COLOR orange]Coco Scrapers[/COLOR][/B][CR]',
                                        nolabel='[B][COLOR white]Πίσω[/COLOR][/B]',yeslabel='[B][COLOR orange]Coco Scrapers[/COLOR][/B]')

        if choice == 1: [xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/CocoScrapersSeren/InstalCocoScrapers.py")'),]
        if choice == 0: [xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/CocoScrapersSeren/CocoScrapersSeren.py")'),]
DialogCocoScrapers()
