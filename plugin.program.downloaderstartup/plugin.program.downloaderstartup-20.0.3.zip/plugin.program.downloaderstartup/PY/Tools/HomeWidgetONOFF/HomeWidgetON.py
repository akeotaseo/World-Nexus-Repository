﻿import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob

def HomeWidgetON():
        choice = xbmcgui.Dialog().yesno('[COLOR orange]Ενεργοποίηση HomeWidget[/COLOR]', 'Ενεργοποίηση HomeWidget.[CR]Για να συνεχίσετε πατήστε [B][COLOR green]HomeWidget ON[/COLOR][/B][CR]και περιμένετε...',
                                        nolabel='[B][COLOR white]Όχι τώρα...[/COLOR][/B]',yeslabel='[B][COLOR green]HomeWidget ON[/COLOR][/B]')

        if choice == 1: [xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_8.py")'),]

HomeWidgetON()