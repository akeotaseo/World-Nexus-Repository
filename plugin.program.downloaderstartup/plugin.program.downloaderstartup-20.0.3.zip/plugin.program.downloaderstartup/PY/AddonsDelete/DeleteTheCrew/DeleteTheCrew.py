﻿import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob

def DeleteTheCrew():
        choice = xbmcgui.Dialog().yesno('[COLOR purple]Διαγραφή The Crew[/COLOR]', 'Με αυτή την επιλογή θα γίνει διαγραφή του πρόσθετου[CR][COLOR purple]The Crew[/COLOR] (μαζί με το repository τις εξαρτήσεις και τα addon_data) και θα πραγματοποιηθεί επαναφόρτωση του προφίλ, με αποτέλεσμα να παγώσει για λίγα δευτερόλεπτα η εικόνα.[CR][CR][CR]Για να συνεχίσετε πατήστε [B][COLOR purple]Διαγραφή The Crew[/COLOR][/B][CR]και περιμένετε...',
                                        nolabel='[B][COLOR white]Άκυρο...[/COLOR][/B]',yeslabel='[B][COLOR purple]Διαγραφή The Crew[/COLOR][/B]')
 
        if choice == 1: [xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/AddonsDelete/DeleteTheCrew/DeleteTheCrewNow.py")'),
                         xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Tools/TempDelete/temp_Delete.py")'),
                         #xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/resources/PY/AutowidgetDelFix.py")'),
                         #xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/resources/PY/InstallAutowidget.py")'),
                         #xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/resources/PY/ThemoviedbhelperDel.py")'),
                         xbmcgui.Dialog().notification("[B][COLOR orange]Διαγραφή The Crew[/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", icon='special://home/addons/plugin.image.World/resources/media/foto/TheCrew.png'),
                         xbmc.sleep(2000),
                         xbmcgui.Dialog().notification("[B][COLOR orange]Επιτυχής Διαγραφή![/COLOR][/B]", "[COLOR white]Αναμονή για Reload Profile...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/rp.png'),
                         xbmc.sleep(2000),
                         xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=forceprofile)'),
                         xbmc.sleep(2000),
                         xbmcgui.Dialog().notification("[B][COLOR orange]Reload Profile[/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/reloadprofile.png'),]

DeleteTheCrew()
