import xbmc, xbmcgui


def KodiBalkanWorldClientPortal():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10, click_11, click_12)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]  ~ Robinhood TV Portal &.... ~[/COLOR][/B]', 
['Portal 1   goodiptv.cc    Max Connections : 3',
 'Portal 2   mana.etnoselo.tv:80',
 'Portal 3   ufospeeds.com:2095',
 'Portal 4   et1.xyz:25461 ',
 'Portal 5   asterix-iptv.club:25461    Max Connections : 50',
 'Portal 6   asterix-iptv.club:25461    Max Connections : 100',
 'Portal 7   13tv.com:8080    Max Connections : 250',
 'Portal 8   xplatinmedia.com:8080    Max Connections : 100',
 'Portal 9   104.243.32.68:25461',
 'Portal 10   exm3u.ofio.xyz',
 'Portal 11   sysadminhost.net:8080    Max Connections : 100',
 'Portal 12   iptvtree.net:8080'
 ])



    if call:
        if call < 0:
            return
        func = funcs[call-12]
        return func()
    else:
        func = funcs[call]
        return func()
    return 




def click_1():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.downloaderstartup/?url=https%3A%2F%2Fgithub.com%2Fakeotaseo%2Fworld_repo%2Fraw%2Fmain%2FUpdater_Matrix%2FW%2FPortal_1.zip&mode=33&name=Portal+1&icon=https%3A%2F%2Fgithub.com%2Fakeotaseo%2Fworld_repo%2Fblob%2Fmain%2FUpdater_Matrix%2Fimage%2Fiptv.jpg%3Fraw%3Dtrue&fanart=https%3A%2F%2Fgithub.com%2Fakeotaseo%2Fworld_repo%2Fblob%2Fmain%2FUpdater_Matrix%2Fimage%2Fiptv.jpg%3Fraw%3Dtrue&description=-&name2=Portal+1&version=")')
    
def click_2():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.downloaderstartup/?url=https%3A%2F%2Fgithub.com%2Fakeotaseo%2Fworld_repo%2Fraw%2Fmain%2FUpdater_Matrix%2FW%2FPortal_2.zip&mode=33&name=Portal+2&icon=https%3A%2F%2Fgithub.com%2Fakeotaseo%2Fworld_repo%2Fblob%2Fmain%2FUpdater_Matrix%2Fimage%2Fiptv.jpg%3Fraw%3Dtrue&fanart=https%3A%2F%2Fgithub.com%2Fakeotaseo%2Fworld_repo%2Fblob%2Fmain%2FUpdater_Matrix%2Fimage%2Fiptv.jpg%3Fraw%3Dtrue&description=-&name2=Portal+2&version=")')

def click_3():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.downloaderstartup/?url=https%3A%2F%2Fgithub.com%2Fakeotaseo%2Fworld_repo%2Fraw%2Fmain%2FUpdater_Matrix%2FW%2FPortal_3.zip&mode=33&name=Portal+3&icon=https%3A%2F%2Fgithub.com%2Fakeotaseo%2Fworld_repo%2Fblob%2Fmain%2FUpdater_Matrix%2Fimage%2Fiptv.jpg%3Fraw%3Dtrue&fanart=https%3A%2F%2Fgithub.com%2Fakeotaseo%2Fworld_repo%2Fblob%2Fmain%2FUpdater_Matrix%2Fimage%2Fiptv.jpg%3Fraw%3Dtrue&description=-&name2=Portal+3&version=")')

def click_4():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.downloaderstartup/?url=https%3A%2F%2Fgithub.com%2Fakeotaseo%2Fworld_repo%2Fraw%2Fmain%2FUpdater_Matrix%2FW%2FPortal_4.zip&mode=33&name=Portal+4&icon=https%3A%2F%2Fgithub.com%2Fakeotaseo%2Fworld_repo%2Fblob%2Fmain%2FUpdater_Matrix%2Fimage%2Fiptv.jpg%3Fraw%3Dtrue&fanart=https%3A%2F%2Fgithub.com%2Fakeotaseo%2Fworld_repo%2Fblob%2Fmain%2FUpdater_Matrix%2Fimage%2Fiptv.jpg%3Fraw%3Dtrue&description=-&name2=Portal+4&version=")')

def click_5():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.downloaderstartup/?url=https%3A%2F%2Fgithub.com%2Fakeotaseo%2Fworld_repo%2Fraw%2Fmain%2FUpdater_Matrix%2FW%2FPortal_5.zip&mode=33&name=Portal+5&icon=https%3A%2F%2Fgithub.com%2Fakeotaseo%2Fworld_repo%2Fblob%2Fmain%2FUpdater_Matrix%2Fimage%2Fiptv.jpg%3Fraw%3Dtrue&fanart=https%3A%2F%2Fgithub.com%2Fakeotaseo%2Fworld_repo%2Fblob%2Fmain%2FUpdater_Matrix%2Fimage%2Fiptv.jpg%3Fraw%3Dtrue&description=-&name2=Portal+5&version=")')

def click_6():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.downloaderstartup/?url=https%3A%2F%2Fgithub.com%2Fakeotaseo%2Fworld_repo%2Fraw%2Fmain%2FUpdater_Matrix%2FW%2FPortal_6.zip&mode=33&name=Portal+6&icon=https%3A%2F%2Fgithub.com%2Fakeotaseo%2Fworld_repo%2Fblob%2Fmain%2FUpdater_Matrix%2Fimage%2Fiptv.jpg%3Fraw%3Dtrue&fanart=https%3A%2F%2Fgithub.com%2Fakeotaseo%2Fworld_repo%2Fblob%2Fmain%2FUpdater_Matrix%2Fimage%2Fiptv.jpg%3Fraw%3Dtrue&description=-&name2=Portal+6&version=")')

def click_7():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.downloaderstartup/?url=https%3A%2F%2Fgithub.com%2Fakeotaseo%2Fworld_repo%2Fraw%2Fmain%2FUpdater_Matrix%2FW%2FPortal_7.zip&mode=33&name=Portal+7&icon=https%3A%2F%2Fgithub.com%2Fakeotaseo%2Fworld_repo%2Fblob%2Fmain%2FUpdater_Matrix%2Fimage%2Fiptv.jpg%3Fraw%3Dtrue&fanart=https%3A%2F%2Fgithub.com%2Fakeotaseo%2Fworld_repo%2Fblob%2Fmain%2FUpdater_Matrix%2Fimage%2Fiptv.jpg%3Fraw%3Dtrue&description=-&name2=Portal+7&version=")')

def click_8():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.downloaderstartup/?url=https%3A%2F%2Fgithub.com%2Fakeotaseo%2Fworld_repo%2Fraw%2Fmain%2FUpdater_Matrix%2FW%2FPortal_8.zip&mode=33&name=Portal+8&icon=https%3A%2F%2Fgithub.com%2Fakeotaseo%2Fworld_repo%2Fblob%2Fmain%2FUpdater_Matrix%2Fimage%2Fiptv.jpg%3Fraw%3Dtrue&fanart=https%3A%2F%2Fgithub.com%2Fakeotaseo%2Fworld_repo%2Fblob%2Fmain%2FUpdater_Matrix%2Fimage%2Fiptv.jpg%3Fraw%3Dtrue&description=-&name2=Portal+8&version=")')

def click_9():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.downloaderstartup/?url=https%3A%2F%2Fgithub.com%2Fakeotaseo%2Fworld_repo%2Fraw%2Fmain%2FUpdater_Matrix%2FW%2FPortal_9.zip&mode=33&name=Portal+9&icon=https%3A%2F%2Fgithub.com%2Fakeotaseo%2Fworld_repo%2Fblob%2Fmain%2FUpdater_Matrix%2Fimage%2Fiptv.jpg%3Fraw%3Dtrue&fanart=https%3A%2F%2Fgithub.com%2Fakeotaseo%2Fworld_repo%2Fblob%2Fmain%2FUpdater_Matrix%2Fimage%2Fiptv.jpg%3Fraw%3Dtrue&description=-&name2=Portal+9&version=")')

def click_10():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.downloaderstartup/?url=https%3A%2F%2Fgithub.com%2Fakeotaseo%2Fworld_repo%2Fraw%2Fmain%2FUpdater_Matrix%2FW%2FPortal_10.zip&mode=33&name=Portal+10&icon=https%3A%2F%2Fgithub.com%2Fakeotaseo%2Fworld_repo%2Fblob%2Fmain%2FUpdater_Matrix%2Fimage%2Fiptv.jpg%3Fraw%3Dtrue&fanart=https%3A%2F%2Fgithub.com%2Fakeotaseo%2Fworld_repo%2Fblob%2Fmain%2FUpdater_Matrix%2Fimage%2Fiptv.jpg%3Fraw%3Dtrue&description=-&name2=Portal+10&version=")')

def click_11():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.downloaderstartup/?url=https%3A%2F%2Fgithub.com%2Fakeotaseo%2Fworld_repo%2Fraw%2Fmain%2FUpdater_Matrix%2FW%2FPortal_11.zip&mode=33&name=Portal+11&icon=https%3A%2F%2Fgithub.com%2Fakeotaseo%2Fworld_repo%2Fblob%2Fmain%2FUpdater_Matrix%2Fimage%2Fiptv.jpg%3Fraw%3Dtrue&fanart=https%3A%2F%2Fgithub.com%2Fakeotaseo%2Fworld_repo%2Fblob%2Fmain%2FUpdater_Matrix%2Fimage%2Fiptv.jpg%3Fraw%3Dtrue&description=-&name2=Portal+11&version=")')

def click_12():
    xbmc.executebuiltin('PlayMedia("plugin://plugin.program.downloaderstartup/?url=https%3A%2F%2Fgithub.com%2Fakeotaseo%2Fworld_repo%2Fraw%2Fmain%2FUpdater_Matrix%2FW%2FPortal_12.zip&mode=33&name=Portal+12&icon=https%3A%2F%2Fgithub.com%2Fakeotaseo%2Fworld_repo%2Fblob%2Fmain%2FUpdater_Matrix%2Fimage%2Fiptv.jpg%3Fraw%3Dtrue&fanart=https%3A%2F%2Fgithub.com%2Fakeotaseo%2Fworld_repo%2Fblob%2Fmain%2FUpdater_Matrix%2Fimage%2Fiptv.jpg%3Fraw%3Dtrue&description=-&name2=Portal+12&version=")')

KodiBalkanWorldClientPortal()
