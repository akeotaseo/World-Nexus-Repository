﻿import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob

def DialogEnableDisabledownloaderstartup():        
        choice = xbmcgui.Dialog().yesno('[COLOR orange]Enable / Disable Update build[/COLOR]', 'Ενεργοποίηση-Απενεργοποίηση αυτόματης ενημέρωσης[CR]του build...',
                                        nolabel='[B][COLOR white]Όχι τώρα...[/COLOR][/B]',yeslabel='[B][COLOR orange]Συνέχεια[/COLOR][/B]')
                                        
        if choice == 1: [xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/Tools/downloaderstartupOnOff/EnableDisabledownloaderstartup.py")'),
                        ]
                         
DialogEnableDisabledownloaderstartup()
