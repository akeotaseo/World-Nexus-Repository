import xbmc, xbmcgui


def Introonoff():
    funcs = (click_1, click_2, click_3, click_4)
    call = xbmcgui.Dialog().select('[B][COLOR=green]Enable[/COLOR][/B]/[B][COLOR=red]Disable[/COLOR]Intro[/B]', 
['[COLOR=green]Download Intro...[/COLOR] (18MB)',
 '[COLOR=green]Enable[/COLOR]',
 '[COLOR=red]Disable[/COLOR]',
 '[COLOR=red]Delete Intro...[/COLOR]'])
 



    if call:
        if call < 0:
            return
        func = funcs[call-4]
        return func()
    else:
        func = funcs[call]
        return func()
    return 




#def click_1():
#    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.apex_sports/?category=live_sport&amp;mode=search)')
#    xbmcgui.Dialog().notification("[B][COLOR orange]TechNEWSology[/COLOR][/B]",'[COLOR white]Για την αναζήτηση αγώνων, πληκτρολογήστε την Ομάδα ή την Χώρα με λατινικούς χαρακτήρες ...[/COLOR]' , icon ='special://home/addons/skin.TechNEWSology/icon.png')

def click_1():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/UpdaterMatrix_4.py")')
    xbmc.sleep(3000)
    xbmc.executebuiltin('Skin.ToggleSetting(HideKodiIntro,Enabled)')

def click_2():
    xbmc.executebuiltin('Skin.ToggleSetting(HideKodiIntro,Enabled)')

def click_3():
    xbmc.executebuiltin('Skin.ToggleSetting(HideKodiIntro,Transparent)')

def click_4():
    xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/AddonsDelete/DeleteIntro.py")')
    xbmc.sleep(3000)
    xbmc.executebuiltin('Skin.ToggleSetting(HideKodiIntro,Transparent)')


Introonoff()
