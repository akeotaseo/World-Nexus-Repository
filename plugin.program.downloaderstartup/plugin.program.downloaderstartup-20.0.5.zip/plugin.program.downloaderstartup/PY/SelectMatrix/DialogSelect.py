﻿import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob

def DialogSelectMatrix():
        choice = xbmcgui.Dialog().yesno('[CR]', 'Η επιλογή αυτή είναι για Test που κάνω στο build.[CR][CR][B]Παρακαλώ μη προχωράτε γιατί μπορεί να προκύψουν δυσλειτουργίες στο build...[/B]',
                                        nolabel='[B][COLOR white]Άκυρο[/COLOR][/B]',yeslabel='[B][COLOR orange]Select Matrix[/COLOR] - [COLOR red]Test[/COLOR][/B]')

        if choice == 1: [xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/SelectMatrix/SelectMatrix.py")'),
                         #xbmcvfs.delete('special://home/addons/plugin.program.downloader19/downloader_startup.py'), 
                         #xbmc.sleep(1000),
                         #xbmcvfs.delete('special://home/userdata/addon_data/plugin.program.downloader19/settings.xml'),
                         #xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/resources/PY/UpdaterMatrixDelFix.py")'),
                         #xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/resources/PY/AutowidgetDelFix.py")'),
                         #xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/resources/PY/InstallAutowidget.py")'),
                         #xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/resources/PY/ThemoviedbhelperDel.py")'),
                         #xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloader19/resources/PY/temp_DeletelFix.py")'),
                         #xbmcgui.Dialog().notification("[B][COLOR orange]Διαγραφή με επιτυχία ![/COLOR][/B]", "[COLOR white]Αναμονή για Reload Profile...[/COLOR]", icon='special://home/addons/plugin.program.downloader19/resources/media/rp.png'),
                         #xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=forceprofile)'),
                         #xbmc.sleep(2000),
                         #plugin.program.downloaderstartup
                         #xbmcgui.Dialog().notification("[B][COLOR orange]Reload Profile[/COLOR][/B]", "[COLOR white]Παρακαλώ περιμένετε...[/COLOR]", #icon='special://home/addons/plugin.program.downloader19/resources/media/reloadprofile.png'),
                         ]

DialogSelectMatrix()
