import os, xbmc, xbmcgui

def InstalCocoScrapers():


    xbmc.executebuiltin('ActivateWindow(10001,"plugin://script.module.cocoscrapers/",return)')

InstalCocoScrapers()                        