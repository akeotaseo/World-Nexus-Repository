﻿import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob

def DialogDeleteAllXXXAddons():
        choice = xbmcgui.Dialog().yesno('[COLOR pink]XXX Addons[/COLOR]', 'Επιθυμείτε την διαγραφή όλων των πρόσθετων Ενηλίκων?[CR]',
                                        nolabel='[B][COLOR white]Όχι τώρα...[/COLOR][/B]',yeslabel='[B][COLOR red]Διαγραφή[/COLOR][/B]')

        if choice == 1: [xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/PY/AddonsDelete/DeleteAllXXXAddons.py")'),]

DialogDeleteAllXXXAddons()
