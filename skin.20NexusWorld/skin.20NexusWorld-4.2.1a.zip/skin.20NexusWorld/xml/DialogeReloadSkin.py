﻿import xbmc, xbmcgui


def DialogeReloadSkin():
        
        choice = xbmcgui.Dialog().yesno('[B][COLOR red]ReloadSkin[/COLOR][/B]', 'Πατήστε [B][COLOR red]ReloadSkin...[/COLOR][/B]',
                                        nolabel='Οχι',yeslabel='[COLOR red]ReloadSkin[/COLOR]')

        if choice == 1: [xbmc.executebuiltin("ReloadSkin()"), 
                         xbmc.sleep(5000),
                         xbmc.executebuiltin('RunScript("special://home/addons/plugin.program.downloaderstartup/service.py")'),]
        #if choice == 0: [xbmc.executebuiltin("ReloadSkin()"),]
                         

DialogeReloadSkin()
