﻿import xbmc

def audiosettings():
    xbmc.executebuiltin("Action(Close)")
    xbmc.executebuiltin("ActivateWindowAndFocus(systemsettings, -99,)")
    xbmc.executebuiltin("Action(Pause)")
    while xbmc.getCondVisibility("Window.IsVisible(systemsettings)") or xbmc.getCondVisibility("Window.IsVisible(dialog)"):
        xbmc.sleep(100)
    xbmc.executebuiltin("Action(Play)")

audiosettings()
