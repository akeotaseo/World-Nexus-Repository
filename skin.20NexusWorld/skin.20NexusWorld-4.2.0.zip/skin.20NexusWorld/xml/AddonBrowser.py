﻿import xbmc

def AddonBrowser():
    xbmc.executebuiltin("Action(Close)")
    xbmc.executebuiltin("ActivateWindow(AddonBrowser,return)")

AddonBrowser()
