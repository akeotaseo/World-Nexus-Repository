﻿import xbmc

def SetingsKodi():
    xbmc.executebuiltin("Action(Close)")
    xbmc.executebuiltin("ActivateWindow(Settings,return)")

SetingsKodi()
