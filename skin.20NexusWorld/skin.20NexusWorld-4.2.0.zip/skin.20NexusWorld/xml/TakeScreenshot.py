﻿import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob

xbmcgui.Dialog().notification("Προσοχή!", "TakeScreenshot.", xbmcgui.NOTIFICATION_INFO, 7000, False)

