﻿import xbmc, xbmcgui
#from updatervar import *

def MyGroups():

    #dialog.notification('[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]', '[COLOR white][B]--->[/B][/COLOR] [COLOR green]My Groups[/COLOR]', icon_Pleasewait, sound=False)
    xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[COLOR white][B]--->[/B][/COLOR] [COLOR green]My Groups[/COLOR]", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/Pleasewait.png')
    #xbmc.executebuiltin("Action(Back)")
    xbmc.executebuiltin("Action(Close)")
    #xbmc.executebuiltin("Action(Back)")
    xbmc.sleep(1000)



    #xbmc.executebuiltin("ActivateWindow(Home)")

    xbmc.executebuiltin("ActivateWindow(10025,plugin://plugin.program.autowidget/?mode=group&refresh&reload)")
    #xbmc.sleep(100)
    #xbmc.executebuiltin("ActivateWindow(10025,plugin://plugin.program.autowidget/?mode=group&refresh&reload,return)")

MyGroups()
