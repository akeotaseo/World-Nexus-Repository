﻿import xbmc

def last_played():
    xbmc.executebuiltin("Action(Close)")
    xbmc.executebuiltin("RunAddon(plugin.video.last_played)")

last_played()
