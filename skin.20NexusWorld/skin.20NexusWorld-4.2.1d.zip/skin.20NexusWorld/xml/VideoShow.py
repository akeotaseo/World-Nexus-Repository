﻿import xbmc

def videoshow():
  #  xbmc.executebuiltin("Action(Close)")
    xbmc.executebuiltin("ActivateWindowAndFocus(osdvideosettings)")
    xbmc.executebuiltin("Action(Pause)")
    xbmc.sleep(500)
    if xbmc.getCondVisibility('system.platform.android'):
        xbmc.executebuiltin('SendClick(-80)')
    else:
        xbmc.executebuiltin('SendClick(-80)')

    while xbmc.getCondVisibility("Window.IsVisible(osdvideosettings)") or xbmc.getCondVisibility("Window.IsVisible(dialog)"):
        xbmc.sleep(100)
    xbmc.executebuiltin("Action(Play)")

videoshow()
