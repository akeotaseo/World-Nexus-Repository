﻿import xbmc, xbmcgui

def MyGroups():
    xbmc.executebuiltin("Action(Close)")
    xbmcgui.Dialog().notification("[B][COLOR orange]Ανακατεύθυνση...[/COLOR][/B]", "[COLOR white][B]--->[/B][/COLOR] [COLOR green]My Select[/COLOR]", sound=False, icon='special://home/addons/plugin.program.downloader19/resources/media/Pleasewait.png')
    xbmc.sleep(2000)
    #xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.autowidget/?mode=group&refresh&reload",return)')
    
    xbmc.executebuiltin('ActivateWindow(10001,"plugin://plugin.program.mypreferences/?content_type=executable&fanart=special%3a%2f%2fhome%2faddons%5cplugin.image.World%5cresources%5cmedia%5cfoto%5cMy%20Select.png&image=special%3a%2f%2fhome%2faddons%5cplugin.image.World%5cresources%5cmedia%5cfoto%5cMy%20Select.png&label=My%20Select&mode=400&path=special%3a%2f%2fprofile%2faddon_data%2fplugin.program.mypreferences%5cSuper%20Favourites%5cMy%20Select",)')
MyGroups()
