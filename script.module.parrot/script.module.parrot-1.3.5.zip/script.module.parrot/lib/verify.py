import requests
import xbmcaddon
import xbmcgui
import time
import hashlib
from falconAPI import FalconAPI

authAddonID = "repository.Parrot"
_ADDON_NAME = xbmcaddon.Addon(authAddonID).getAddonInfo('name')

def getUsername(): return xbmcaddon.Addon(authAddonID).getSetting("username")
def getPassword(): return xbmcaddon.Addon(authAddonID).getSetting("password")

def offlineMode(): exit()

def login(username = getUsername(), password = getPassword()):
    _ADDON = xbmcaddon.Addon(authAddonID)
    if username == "" or password == "":
        _ADDON.setSetting('verified', 'false')
        _ADDON.setSetting('verifiedExpires', '0')
        _ADDON.setSetting('oldCreds', '')
        xbmcgui.Dialog().notification(_ADDON_NAME, "No credentials were entered", xbmcgui.NOTIFICATION_INFO, 5000)
        _ADDON.openSettings()
        return False
    
    
    def checkVerified():
        if _ADDON.getSetting('verified') != 'true':
            return False
        
        if not _ADDON.getSetting('token'):
            return False
        
        try:
            if int(_ADDON.getSetting('verifiedExpires')) < int(time.time()):
                return False
        except ValueError:
            return False
        
        if _ADDON.getSetting('oldCreds') != hashlib.sha256(f"{username}:{password}".encode('utf-8')).hexdigest():
            return False
        
        return True
    
    if checkVerified():
        return True
    


    data = {}
    for addon_ in ["script.module.parrot", "plugin.video.parrottv", "repository.Parrot", "script.module.falconscrapers", "plugin.video.kukajto"]:
        try: data[addon_] = xbmcaddon.Addon(addon_).getAddonInfo("version")
        except: pass



    jsonResp = FalconAPI(username=username, password=password).login(extendedData=data)

    if jsonResp['status'] == 'success':
        _ADDON.setSetting('verified', 'true')
        _ADDON.setSetting('verifiedExpires', str(int(time.time()) + (24 * 60 * 60)))
        _ADDON.setSetting('token', jsonResp["token"])
        _ADDON.setSetting('oldCreds', hashlib.sha256(f"{username}:{password}".encode('utf-8')).hexdigest())
        return True

    _ADDON.setSetting('verified', 'false')
    _ADDON.setSetting('verifiedExpires', '0')
    _ADDON.setSetting('token', '')
    _ADDON.setSetting('oldCreds', '')
    xbmcgui.Dialog().notification(_ADDON_NAME, "Invalid credentials", xbmcgui.NOTIFICATION_INFO, 5000)
    _ADDON.openSettings()
    return False
