from urllib.parse import urlencode
import random
import requests

class FalconAPI:
    def __init__(self) -> None:
        self.apis = {
            #"Falcon": "https://falconpanel.parrotdevelopers.repl.co/api/",
            "Falcon Load Balancer 1": "https://falconlb01.parrotdevelopers.repl.co/api/",
            "Falcon Load Balancer 2": "https://falconlb02.parrotdevelopers.repl.co/api/",
            "Falcon Load Balancer 3": 'https://falconlb03.parrotdevelopers.repl.co/api/',
            "Falcon Load Balancer 4": 'https://falconlb04.parrotdevelopers.repl.co/api/',
        }

        #statuses = requests.get("https://stats.uptimerobot.com/api/getMonitorList/XPP2xF48QP?page=1").json()["psp"]["monitors"]
        #working = []
        #for status in statuses:
        #    if status["statusClass"] != "success": continue
        #    if status["name"] not in self.apis: continue
        #    working.append(self.apis[status["name"]])

        #self.api = random.choice(working)
        self.api = random.choice(list(self.apis.values()))

    def createURL(self, dir, **kwargs):
        if len(kwargs) == 0: return f"{self.api}{dir}"
        return f"{self.api}{dir}?{urlencode(kwargs)}"
    